<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-19 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:24:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 06:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 06:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 06:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 06:31:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:10:17 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:11:02 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 12:25:23 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 07:02:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:02:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:02:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:02:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:02:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:04:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:04:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:06:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:06:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:07:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:12:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:12:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:16:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:16:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:16:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:16:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:16:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:21:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:22:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:24:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:34:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:34:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:35:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 07:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 07:35:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 17:29:22 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:29:22 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:29:22 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:29:22 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:50 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 17:34:58 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-19 13:00:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:00:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:02:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:03:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:03:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:03:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:04:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:04:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:11:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:24:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:24:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-19 13:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-19 13:25:23 --> 404 Page Not Found: Assets/js
