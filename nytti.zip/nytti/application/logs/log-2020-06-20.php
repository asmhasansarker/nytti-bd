<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-20 04:14:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:19:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:39:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:42:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:43:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:47:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 04:53:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:03:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:05:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:06:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:07:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:08:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:16:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:17:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:19:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:25:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:26:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:30:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:33:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:36:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:37:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:37:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:38:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:38:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:38:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:39:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:44:02 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 05:44:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 05:45:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:46:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:46:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:48:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:48:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:50:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:53:20 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:53:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:53:30 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:53:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:53:42 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:53:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:53:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:53:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:53:49 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-20 05:53:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:53:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:54:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:54:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:54:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:54:51 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:55:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:55:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:55:09 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-20 05:55:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 05:55:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 05:57:26 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 05:57:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 06:00:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 06:00:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:00:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 06:00:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:03:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:12:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:18:40 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 06:18:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:21:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:22:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:24:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:25:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:27:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:31:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:32:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:33:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:34:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:40:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:41:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:44:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:46:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:49:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:49:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 06:49:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:30:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:32:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:36:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:44:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:56:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 08:58:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:01:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:01:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:02:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:03:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:04:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:06:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:06:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:06:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:07:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:07:15 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-20 09:07:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:10:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:12:10 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-20 09:12:10 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-20 09:13:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:24:02 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-20 09:24:02 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-20 09:24:06 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-20 09:24:06 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-20 09:26:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:26:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:29:38 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 09:29:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:48:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 09:48:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:48:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 09:54:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 09:55:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:07:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:11:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:23:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:28:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:28:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:41:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:43:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:46:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:50:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 10:58:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:03:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:04:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:07:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:10:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:17:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:20:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:32:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:40:24 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 11:40:24 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-20 11:45:07 --> Severity: Notice --> Undefined index: teach_gender /home/themes91/public_html/ci/e-academy/application/views/student/extra_classes.php 18
ERROR - 2020-06-20 11:46:32 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-20 11:46:32 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-20 11:46:32 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-20 11:46:32 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-20 11:46:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-20 11:46:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-20 11:46:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-20 11:47:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-20 11:47:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-20 11:47:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-20 11:57:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 11:57:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 12:03:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:06:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:08:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:10:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:12:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:19:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:20:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:24:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:28:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:31:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:08 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-20 12:32:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:32:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:43:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:44:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:44:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:53:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:53:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:53:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:54:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 12:55:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:00:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:00:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:07:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:07:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:09:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:10:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:10:28 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 13:10:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:10:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:10:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-20 13:11:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:11:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:11:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:12:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:23:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-20 13:23:18 --> 404 Page Not Found: api/Welcome/update_app_used
