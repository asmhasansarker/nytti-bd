<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-26 10:34:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:34:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:34:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:34:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:34:37 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 32 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 92
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 32 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 95
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 33 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 92
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 33 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 95
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 34 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 92
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 34 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 95
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 35 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 92
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 35 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 95
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 36 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 92
ERROR - 2020-08-26 10:39:53 --> Severity: Notice --> Uninitialized string offset: 36 /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 95
ERROR - 2020-08-26 10:40:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:40:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:40:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:40:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:40:11 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:41:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:41:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:41:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:41:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 10:41:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-26 06:39:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 06:39:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:39:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:58:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:58:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 06:58:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 06:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:58:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 06:58:11 --> Query error: Table 'themes91_eacademy.exams1' doesn't exist - Invalid query: SELECT *
FROM exams1 use index (id)
WHERE `admin_id` = '1'
AND `type` = 1
AND concat(mock_sheduled_date ," ",mock_sheduled_time) <= '2020-08-26 06:58:11'
AND `batch_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-08-26 07:00:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 07:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:00:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:06:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:06:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 07:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:14:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:14:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 07:16:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 07:16:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 07:16:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 13:43:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 13:43:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 08:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:25:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:25:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:26:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:26:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:26:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:28:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:28:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:28:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:28:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:28:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:31:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:31:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:31:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:32:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:32:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:33:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:34:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:40:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:40:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:44:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:44:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:44:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:44:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:44:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:44:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:45:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:45:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:47:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:47:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:47:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:47:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:48:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:48:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:48:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:48:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:50:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:50:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:50:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:53:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:53:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:53:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 08:53:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 08:53:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:00:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:00:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:30:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:00:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:00:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:00:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:31:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 14:31:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:01:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 14:32:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:02:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:02:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:32:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:02:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:02:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:33:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:03:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:03:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:03:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:34:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:04:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:35:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 09:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 09:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 14:35:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 14:43:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 14:43:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-26 09:32:52 --> Query error: Unknown column 'name' in 'field list' - Invalid query: SELECT `name`
FROM `batches`
WHERE `id` = '1'
ORDER BY `id` DESC
 LIMIT 1
ERROR - 2020-08-26 10:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 10:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 10:53:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 11:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 11:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 11:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 11:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 11:57:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:05:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:05:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:05:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:05:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:05:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:07:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:07:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:07:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:07:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:07:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:10:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:10:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:11:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:11:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:12:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:12:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:12:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:12:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:12:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:13:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:13:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:14:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-26 12:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:14:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-26 12:30:35 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:31:47 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:32:37 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:36:17 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:36:17 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:37:25 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:37:37 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:41:53 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-26 12:42:16 --> 404 Page Not Found: Student/answer-sheet
