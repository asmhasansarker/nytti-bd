<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-09 05:09:39 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-09 05:09:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:09:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:11:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:11:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:16:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:16:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:16:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:18:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:18:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:22:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:22:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:22:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:24:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:31:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:31:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:31:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 05:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:36:39 --> Severity: error --> Exception: syntax error, unexpected '$data_arr' (T_VARIABLE) /home/kamleshyadav/public_html/academy-portal/application/controllers/Front_ajax.php 473
ERROR - 2020-06-09 05:56:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:56:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 05:56:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 06:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 06:16:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 06:16:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-09 07:26:03 --> 404 Page Not Found: Admin/x
ERROR - 2020-06-09 14:16:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 14:16:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-09 14:16:41 --> 404 Page Not Found: Assets/css
