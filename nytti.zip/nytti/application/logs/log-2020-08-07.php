<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-07 11:39:11 --> Query error: Key 'id' doesn't exist in table 'attendance' - Invalid query: SELECT *
FROM attendance use index (id)
WHERE `student_id` = ''
AND  `date` LIKE '%-%' ESCAPE '!'
ERROR - 2020-08-07 11:45:06 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 11:45:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 11:45:06 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 11:45:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 12:00:43 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 12:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 12:00:43 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 12:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 06:33:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-07 06:33:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-07 06:35:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-07 12:06:13 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-07 12:45:14 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 12:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-07 12:45:14 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 12:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-07 07:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 07:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 07:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:58:31 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 12:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 12:58:31 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 12:58:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 07:28:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 07:28:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 07:28:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 07:42:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-07 07:53:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-07 08:36:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:36:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 08:36:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 08:36:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:36:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:36:54 --> 404 Page Not Found: Teacher/student-attendance
ERROR - 2020-08-07 08:38:06 --> 404 Page Not Found: Teacher/student-attendance
ERROR - 2020-08-07 08:38:21 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-08-07 08:39:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 08:39:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:39:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:39:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:39:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 08:39:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 08:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 08:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 14:10:03 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-07 14:10:03 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-07 14:10:03 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-07 08:42:33 --> Severity: Notice --> Undefined variable: header /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 399
ERROR - 2020-08-07 08:59:43 --> Severity: Notice --> Undefined variable: id /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 233
ERROR - 2020-08-07 08:59:43 --> Severity: Notice --> Undefined variable: header /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 235
ERROR - 2020-08-07 14:29:43 --> Severity: error --> Exception: Too few arguments to function Ajaxcall::student_attendance(), 2 passed in /home/themes91/public_html/ci/e-academy/system/core/CodeIgniter.php on line 532 and exactly 3 expected /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 4028
ERROR - 2020-08-07 09:00:22 --> Severity: Notice --> Undefined variable: header /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 236
ERROR - 2020-08-07 09:05:58 --> 404 Page Not Found: Student/student-attendance
ERROR - 2020-08-07 09:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:24:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:31:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 15:11:16 --> Severity: Notice --> Undefined variable: answer /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3997
ERROR - 2020-08-07 09:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:41:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:41:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:41:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:41:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'F' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3978
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3979
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3995
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'C' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'D' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'E' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'F' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3978
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3979
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3995
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'C' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'D' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'E' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'F' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3978
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3979
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3995
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'B' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'C' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'D' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 15:20:32 --> Severity: Warning --> Illegal string offset 'E' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3996
ERROR - 2020-08-07 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:50:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:50:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:52:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:52:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 15:22:22 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3974
ERROR - 2020-08-07 09:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 15:23:51 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3975
ERROR - 2020-08-07 09:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:55:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:55:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 15:25:48 --> Severity: Warning --> Illegal string offset 'A' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3976
ERROR - 2020-08-07 09:57:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 09:57:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:57:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 09:57:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:06:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:06:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:06:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:06:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 10:15:14 --> 404 Page Not Found: Uploads/demo
ERROR - 2020-08-07 10:16:26 --> 404 Page Not Found: Uploads/demo
ERROR - 2020-08-07 10:17:35 --> 404 Page Not Found: Uploads/demo
ERROR - 2020-08-07 10:17:45 --> 404 Page Not Found: Uploads/demo
ERROR - 2020-08-07 15:54:03 --> Severity: Notice --> Undefined variable: good /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 222
ERROR - 2020-08-07 15:54:03 --> Severity: Notice --> Undefined variable: avarage /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 236
ERROR - 2020-08-07 15:54:03 --> Severity: Notice --> Undefined variable: poor /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 250
ERROR - 2020-08-07 16:00:27 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 16:00:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 16:00:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 106
ERROR - 2020-08-07 16:00:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 107
ERROR - 2020-08-07 16:00:27 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 16:01:17 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 16:01:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 16:01:17 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 16:01:34 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 16:01:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 16:01:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 106
ERROR - 2020-08-07 16:01:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 107
ERROR - 2020-08-07 16:01:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 10:55:37 --> 404 Page Not Found: Admin/index
ERROR - 2020-08-07 10:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:57:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 10:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 10:57:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:01:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:01:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:02:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:03:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:03:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:03:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:03:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:05:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:05:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:05:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:05:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:07:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:07:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:17:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:17:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:19:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:19:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:20:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:20:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:20:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:20:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:21:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:21:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:25:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:27:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:28:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:28:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:28:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:28:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:28:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:28:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:28:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:28:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 16:58:47 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 16:58:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 16:58:47 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 16:59:01 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 16:59:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 16:59:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 106
ERROR - 2020-08-07 16:59:01 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 107
ERROR - 2020-08-07 16:59:01 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 11:29:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:29:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:29:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:29:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:30:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:30:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:30:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:30:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 17:00:46 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 258
ERROR - 2020-08-07 17:02:10 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:02:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:02:10 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:02:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:03:31 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:03:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:03:31 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 17:07:09 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:07:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:07:09 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:07:09 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 11:37:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:37:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 17:07:26 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:07:26 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 11:37:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:37:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 17:07:51 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:07:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:07:51 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:07:51 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 17:07:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:07:51 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 11:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:38:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:38:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:38:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 17:08:42 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:08:42 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:08:42 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 11:38:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:38:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:38:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:40:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:41:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:41:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:47:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:47:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:47:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:47:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:48:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:48:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:49:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:50:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:50:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:50:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:53:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 17:23:19 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:23:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:23:19 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 17:23:19 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:23:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:23:19 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 11:53:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 11:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 11:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 17:24:45 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:24:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:24:45 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 17:24:45 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 148
ERROR - 2020-08-07 17:24:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 105
ERROR - 2020-08-07 17:24:45 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 111
ERROR - 2020-08-07 17:25:48 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:25:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:25:48 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:25:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:26:08 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 94
ERROR - 2020-08-07 17:26:08 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 17:26:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 105
ERROR - 2020-08-07 12:02:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:02:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:15:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:15:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:15:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:15:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:15:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:15:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:15:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:15:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:17:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:17:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:17:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:17:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:19:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:19:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:19:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:19:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:20:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:20:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:20:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:20:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:23:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:30:46 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-08-07 12:30:51 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-08-07 12:31:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:31:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:31:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:31:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:31:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:33:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:33:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:33:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:35:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:35:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:35:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:36:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:36:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:37:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:37:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:37:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 18:08:24 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-07 18:08:24 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 70
ERROR - 2020-08-07 18:08:25 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 795
ERROR - 2020-08-07 12:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:38:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:38:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:42:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:42:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:45:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:48:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:48:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:48:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:48:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:49:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:49:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:49:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:49:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:51:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:51:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:58:42 --> 404 Page Not Found: Admin/index
ERROR - 2020-08-07 12:58:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 12:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 12:58:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:04:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-07 13:04:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:04:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-07 13:05:26 --> 404 Page Not Found: Assets/css
