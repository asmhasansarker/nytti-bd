<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 05:36:59 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 05:36:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:36:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:37:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:37:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:37:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:37:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:38:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:38:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:38:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 05:38:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 05:38:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:01:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:01:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 06:13:56 --> 404 Page Not Found: Student/index
ERROR - 2020-06-03 06:17:33 --> 404 Page Not Found: Student/index
ERROR - 2020-06-03 06:18:27 --> 404 Page Not Found: Student/index
ERROR - 2020-06-03 06:19:39 --> 404 Page Not Found: Teacher/dashboard
ERROR - 2020-06-03 06:24:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:24:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 06:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:28:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 06:33:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-03 06:33:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 06:33:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-03 08:12:15 --> Query error: Unknown column 'map_api' in 'field list' - Invalid query: UPDATE `frontend_details` SET `cont_heading` = 'Contact Us For You Query', `cont_sub_heading` = 'START WITH US', `cont_form_heading` = 'Send Us A Message', `mobile` = '1234567890', `email` = 'example@email.com', `facebook` = 'https://www.facebook.com', `youtube` = 'https://www.youtube.com', `twitter` = 'https://www.twitter.com', `instagram` = 'https://www.instagram.com', `linkedin` = 'https://www.linkedin.com', `map_api` = 'AIzaSyBY6rgnfIZd8qdQ9a3bxM4rkkCK9e7Uy-4', `address` = '04 A Agroha Nagar, Dewas, Madhya Pradesh'
WHERE `id` = 1 LIMIT 1
ERROR - 2020-06-03 13:40:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp\www\e-academy\application\views\admin\extra_classes.php 91
