<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-13 06:18:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 06:18:10 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 06:18:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 06:18:19 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 06:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 06:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 06:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 06:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 06:20:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 06:20:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 06:20:18 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 07:20:39 --> 404 Page Not Found: api/Home/get_exam_paper
ERROR - 2020-08-13 07:33:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 07:33:56 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 08:18:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 08:18:01 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 08:28:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 08:33:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 08:33:15 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-13 08:34:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-13 08:49:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 08:49:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 08:49:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 08:49:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 15:26:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 15:26:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 15:26:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 15:26:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 09:58:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 09:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 09:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 09:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 09:58:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 09:58:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 15:28:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 15:28:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2907
ERROR - 2020-08-13 10:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 10:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:13:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:13:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:23:21 --> 404 Page Not Found: Privacypolicy/index
ERROR - 2020-08-13 10:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:27:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:27:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 10:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:29:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 10:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:29:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 10:55:54 --> 404 Page Not Found: Admin/privacy-policy
ERROR - 2020-08-13 11:02:59 --> 404 Page Not Found: Admin_profile/privacy_policy
ERROR - 2020-08-13 11:14:37 --> 404 Page Not Found: Ajaxcall/updatePrivacyPolicy
ERROR - 2020-08-13 11:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:14:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:14:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:14:44 --> 404 Page Not Found: Ajaxcall/updatePrivacyPolicy
ERROR - 2020-08-13 11:16:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:4321) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-13 11:16:36 --> Severity: Compile Error --> Cannot redeclare Ajaxcall::updateCertificateSetting() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 4321
ERROR - 2020-08-13 11:16:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:16:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:16:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:4321) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-13 11:16:47 --> Severity: Compile Error --> Cannot redeclare Ajaxcall::updateCertificateSetting() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 4321
ERROR - 2020-08-13 11:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:17:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:20:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:20:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:20:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:20:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:38:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:38:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:38:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:38:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:38:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:39:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:39:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:39:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:42:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:42:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:49:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-13 11:49:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:49:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:49:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:49:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-13 11:54:38 --> 404 Page Not Found: Home/privacy-policy
ERROR - 2020-08-13 11:54:42 --> 404 Page Not Found: Privacy-policy/index
ERROR - 2020-08-13 11:54:49 --> 404 Page Not Found: Privacypolicy/index
ERROR - 2020-08-13 12:52:13 --> 404 Page Not Found: api/Certificate/index
ERROR - 2020-08-13 18:28:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php:667) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-13 18:28:09 --> Severity: Compile Error --> Switch statements may only contain one default clause /home/themes91/public_html/ci/e-academy/application/third_party/mpdf/mpdf.php 1422
ERROR - 2020-08-13 18:52:10 --> Severity: error --> Exception: FPDF error: Some data has already been output, can't send PDF file (output started at /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php:668) /home/themes91/public_html/ci/e-academy/application/third_party/fpdf/fpdf.php 271
ERROR - 2020-08-13 18:52:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php:668) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
