<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-26 04:15:51 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `name` LIKE '%s%' ESCAPE '!'
AND  `name` LIKE '%s%' ESCAPE '!'
ERROR - 2020-06-26 05:11:56 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 05:11:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 05:15:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 05:15:27 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 05:59:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 05:59:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 05:59:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 06:10:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:11:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:17:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:18:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:21:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:23:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:24:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:24:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:29:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:30:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:30:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:30:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:37:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:37:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:48:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:56:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 06:56:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:21:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:23:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:24:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:24:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:24:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:25:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:25:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:25:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:26:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:28:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:29:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:29:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:29:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:30:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:31:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:33:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:33:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:33:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:34:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:34:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 07:34:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:34:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:43:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:43:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:50:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:53:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:55:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:57:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 08:59:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:02:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:03:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:05:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:07:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:07:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:11:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:12:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:20:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:21:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:24:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 09:25:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:11:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 10:11:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:11:39 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 10:11:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:12:13 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 511
ERROR - 2020-06-26 10:12:13 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 511
ERROR - 2020-06-26 10:12:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:12:13 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 511
ERROR - 2020-06-26 10:14:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:15:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:24:08 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 519
ERROR - 2020-06-26 10:24:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:24:08 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 519
ERROR - 2020-06-26 10:24:08 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 519
ERROR - 2020-06-26 10:28:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:33:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:33:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:38:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:38:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 10:39:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:39:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 10:39:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:40:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 10:40:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:40:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:40:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 16:11:00 --> Severity: Notice --> Undefined variable: currentDate /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 515
ERROR - 2020-06-26 16:11:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `status` = 1
AND `added_at` >= '2020-06-26 15:06:40'
ORDER BY `id` DE' at line 4 - Invalid query: SELECT *
FROM vacancy use index (id)
WHERE `admin_id` = '1'
AND `last_date` > `IS` `NULL`
AND `status` = 1
AND `added_at` >= '2020-06-26 15:06:40'
ORDER BY `id` DESC
ERROR - 2020-06-26 16:11:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-26 10:41:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:42:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:43:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:45:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:45:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 10:45:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 10:53:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:54:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:54:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:54:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 10:57:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 16:27:33 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-26 16:27:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-26 10:58:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 16:29:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`15:06:40`
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND `added_at` >= `2020-06-26` `15:06:40`
ORDER BY `id` DESC
ERROR - 2020-06-26 16:30:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`15:06:40`
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND `added_at` >= `2020-06-26` `15:06:40`
ORDER BY `id` DESC
ERROR - 2020-06-26 11:04:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:05:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:11:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 11:11:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 11:11:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 11:14:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 11:14:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 11:14:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 11:14:22 --> 404 Page Not Found: Teacher/live-class
ERROR - 2020-06-26 11:15:33 --> 404 Page Not Found: Teacher_profile/live_class
ERROR - 2020-06-26 11:17:12 --> 404 Page Not Found: Teacher_profile/live_class
ERROR - 2020-06-26 16:47:47 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-26 16:47:47 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-26 11:22:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:31:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:34:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:36:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:37:47 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-26 11:37:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:41:41 --> 404 Page Not Found: Teacher/class
ERROR - 2020-06-26 11:43:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 11:44:23 --> 404 Page Not Found: Teacher/start_live_class
ERROR - 2020-06-26 11:44:36 --> Severity: Notice --> Undefined variable: header /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 235
ERROR - 2020-06-26 11:45:53 --> Severity: Notice --> Undefined variable: header /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 235
ERROR - 2020-06-26 11:47:22 --> 404 Page Not Found: Teacher/js
ERROR - 2020-06-26 11:47:22 --> 404 Page Not Found: Teacher/js
ERROR - 2020-06-26 11:47:23 --> 404 Page Not Found: Teacher/js
ERROR - 2020-06-26 11:47:23 --> 404 Page Not Found: Teacher/js
ERROR - 2020-06-26 11:59:03 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 100
ERROR - 2020-06-26 12:00:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:01:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:16:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:16:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:19:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:19:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:20:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:20:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 17:50:26 --> Query error: Table 'themes91_eacademy.leaves' doesn't exist - Invalid query: UPDATE `leaves` SET `status` = '1'
WHERE `id` = '8'
ERROR - 2020-06-26 12:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:28:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:28:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:32:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:32:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:32:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 12:32:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 12:40:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:42:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:54:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:54:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 12:58:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 13:05:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 13:08:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 13:10:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 13:12:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-26 13:14:25 --> 404 Page Not Found: Admin/manage-teacher-leave
ERROR - 2020-06-26 13:15:50 --> 404 Page Not Found: Admin/manage-teacher-leave
ERROR - 2020-06-26 13:16:29 --> 404 Page Not Found: Admin_profile/manage_teacher_leave
ERROR - 2020-06-26 13:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:26:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:26:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:27:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:27:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:34:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:34:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:38:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:38:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-26 13:38:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-26 13:38:48 --> 404 Page Not Found: Assets/js
