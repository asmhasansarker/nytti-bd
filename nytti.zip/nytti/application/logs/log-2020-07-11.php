<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-11 11:00:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-11 11:00:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:00:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:00:56 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:01:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:01:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:01:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:01:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:01:36 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:01:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:01:46 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-11 11:01:56 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:01:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:02:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:02:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:02:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:02:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:02:39 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-11 11:02:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:04:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-11 11:04:00 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-11 11:05:13 --> 404 Page Not Found: api/Notice/show_ads
