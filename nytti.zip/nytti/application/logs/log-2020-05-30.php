<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-30 07:22:01 --> 404 Page Not Found: api/Login/index
ERROR - 2020-05-30 07:22:18 --> 404 Page Not Found: api/Student/login
ERROR - 2020-05-30 07:23:27 --> 404 Page Not Found: api/Student/login
ERROR - 2020-05-30 07:23:31 --> 404 Page Not Found: api//index
ERROR - 2020-05-30 07:24:54 --> 404 Page Not Found: api//index
ERROR - 2020-05-30 10:08:04 --> Severity: error --> Exception: syntax error, unexpected ')' C:\wamp\www\e-academy\application\controllers\api\Student.php 23
ERROR - 2020-05-30 10:08:39 --> Severity: error --> Exception: syntax error, unexpected ')' C:\wamp\www\e-academy\application\controllers\api\Student.php 23
ERROR - 2020-05-30 10:25:00 --> 404 Page Not Found: api/Home/app_version
ERROR - 2020-05-30 10:25:17 --> Query error: Table 'eacademy.app_versions' doesn't exist - Invalid query: SELECT *
FROM `app_versions`
ERROR - 2020-05-30 10:25:17 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp\www\e-academy\application\models\Db_model.php 64
ERROR - 2020-05-30 10:25:20 --> Query error: Table 'eacademy.app_versions' doesn't exist - Invalid query: SELECT *
FROM `app_versions`
ERROR - 2020-05-30 10:25:20 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\wamp\www\e-academy\application\models\Db_model.php 64
ERROR - 2020-05-30 11:03:13 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' C:\wamp\www\e-academy\application\controllers\api\Home.php 84
ERROR - 2020-05-30 11:03:39 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' C:\wamp\www\e-academy\application\controllers\api\Home.php 84
ERROR - 2020-05-30 11:04:07 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' C:\wamp\www\e-academy\application\controllers\api\Home.php 84
ERROR - 2020-05-30 11:04:33 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ';' or '{' C:\wamp\www\e-academy\application\controllers\api\Home.php 84
