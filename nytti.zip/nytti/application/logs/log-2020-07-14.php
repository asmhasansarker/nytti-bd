<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 12:24:52 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:24:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:24:52 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-14 12:25:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:25:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:27:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:27:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:28:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:28:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:31:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:31:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:31:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:31:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:35:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:35:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:38:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:38:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:40:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 12:40:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:41:00 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-14 12:41:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 13:20:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 13:20:50 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-14 13:25:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-14 13:25:17 --> 404 Page Not Found: api/Welcome/show_survey
