<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-10 06:04:06 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 45
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 185
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 188
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-10 11:34:06 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-10 06:04:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 45
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 185
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 188
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-10 11:34:15 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-10 11:35:26 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-10 11:35:26 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-10 11:35:37 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-10 11:35:37 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-10 11:36:59 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-10 11:36:59 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
