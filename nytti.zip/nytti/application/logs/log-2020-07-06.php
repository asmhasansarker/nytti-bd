<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-06 07:20:19 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 09:21:33 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 09:27:59 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 09:29:16 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 09:57:18 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 09:57:49 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 10:03:32 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 10:12:25 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 10:14:59 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 10:27:43 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 10:36:12 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 11:00:02 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 11:51:28 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
ERROR - 2020-07-06 12:14:42 --> 404 Page Not Found: Liveclassdemo/external_api.min.map
