<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-13 05:25:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:25:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:25:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:26:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:12 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:26:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:30 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 05:26:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:26:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:30:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:31:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:32:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:32:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:33:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:34:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:34:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:35:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:37:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:39:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:39:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:40:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:40:08 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 05:40:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:42:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:43:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:43:21 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-13 05:43:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:43:59 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 05:44:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:44:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:46:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:46:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:48:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:49:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 05:49:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 06:33:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 06:33:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 06:33:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 06:33:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 06:37:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 06:37:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 06:37:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 07:11:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 07:11:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 07:11:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 07:13:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 07:13:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 07:13:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 08:29:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 08:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 08:29:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:29:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:45:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:45:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 08:46:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:46:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 08:46:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:08:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:08:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:14:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:14:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:14:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:14:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:14:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:14:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:15:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:15:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:17:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:17:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:17:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:18:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 09:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:18:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 09:39:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:39:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:39:51 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:39:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:40:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:40:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:40:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:40:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:40:32 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:40:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:40:36 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 09:40:44 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:40:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:41:56 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-13 09:42:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 09:42:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:51:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 09:51:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:20:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:20:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 10:20:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:20:31 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 10:24:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 10:24:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:24:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:24:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 10:25:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:25:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-13 10:25:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:26:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:27:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:28:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:28:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:31:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:32:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:32:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:32:39 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 10:32:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:32:49 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 10:32:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:33:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:33:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:33:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:33:33 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 10:33:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:41:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:42:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:42:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:46:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 10:54:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:09:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:09:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:09:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 11:30:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:32:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:32:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:33:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:34:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 11:44:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:44:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 11:44:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 11:57:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:58:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 11:58:12 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-13 11:58:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 12:05:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-13 12:18:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-13 13:11:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:11:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:11:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:11:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:11:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:13:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:13:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:13:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:14:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:14:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:14:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:15:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:15:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:15:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:15:35 --> Severity: error --> Exception: syntax error, unexpected '$subjectData' (T_VARIABLE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 305
ERROR - 2020-06-13 13:16:03 --> Severity: error --> Exception: syntax error, unexpected '$subjectData' (T_VARIABLE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 348
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined index: batch_teacher /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 347
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined index: batch_subject /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 351
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined index: batch_subject /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 352
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined index: batch_chapter /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 352
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 353
ERROR - 2020-06-13 13:17:00 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 354
ERROR - 2020-06-13 13:18:54 --> Severity: Notice --> Undefined index: batch_subject /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 346
ERROR - 2020-06-13 13:18:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 346
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 348
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 352
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 353
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined index:  /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 353
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 354
ERROR - 2020-06-13 13:22:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 355
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Only variables should be passed by reference /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 363
ERROR - 2020-06-13 13:23:54 --> Severity: Warning --> array_unique() expects parameter 1 to be array, integer given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 363
ERROR - 2020-06-13 13:23:54 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 364
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 348
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 352
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 353
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined index:  /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 353
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 354
ERROR - 2020-06-13 13:23:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 355
ERROR - 2020-06-13 13:30:57 --> Severity: Notice --> Only variables should be passed by reference /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 354
ERROR - 2020-06-13 13:31:30 --> Severity: Warning --> array_merge(): Argument #2 is not an array /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 354
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 350
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 366
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 367
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined index:  /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 367
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 368
ERROR - 2020-06-13 13:36:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 369
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 349
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 365
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 366
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined index:  /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 366
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 367
ERROR - 2020-06-13 13:37:41 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 368
ERROR - 2020-06-13 13:43:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:43:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:43:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:45:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:45:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:45:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:45:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:45:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:45:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:45:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-13 13:45:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-13 13:45:51 --> 404 Page Not Found: Assets/js
