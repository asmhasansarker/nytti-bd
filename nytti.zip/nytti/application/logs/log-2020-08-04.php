<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-04 06:34:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:34:42 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 06:34:43 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 06:35:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:35:33 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 06:35:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 06:35:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:41:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:41:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 06:42:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:43:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:44:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:47:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:47:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 06:50:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:50:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:50:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 06:51:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:51:07 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 06:51:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:52:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:55:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 06:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 06:56:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 06:56:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:56:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:56:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 06:56:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 06:56:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:03:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:04:22 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 07:04:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:04:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:04:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:04:36 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 07:04:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:04:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:04:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:05:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:05:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:05:07 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:05:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:05:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:05:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:05:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 07:05:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:06:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:06:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:06:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:06:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:07:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:07:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:07:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:37:31 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1471
ERROR - 2020-08-04 12:37:31 --> Query error: Unknown column 'batch_id' in 'field list' - Invalid query: INSERT INTO `extra_classes` (`teacher_id`, `batch_id`, `date`, `start_time`, `end_time`, `description`, `admin_id`, `status`, `added_at`) VALUES ('6', Array, '2020-08-04', '13:00:00', '14:00:00', 'dsds', '1', 'Incomplete', '2020-08-04 12:37:31')
ERROR - 2020-08-04 12:37:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2433) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-04 07:07:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:07:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:07:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:07:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:07:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:07:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:08:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:08:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:08:06 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 07:08:19 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:08:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 12:38:19 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1471
ERROR - 2020-08-04 12:38:19 --> Query error: Unknown column 'batch_id' in 'field list' - Invalid query: INSERT INTO `extra_classes` (`teacher_id`, `batch_id`, `date`, `start_time`, `end_time`, `description`, `admin_id`, `status`, `added_at`) VALUES ('6', Array, '2020-08-04', '12:00:00', '12:30:00', 'sdsdas', '1', 'Incomplete', '2020-08-04 12:38:19')
ERROR - 2020-08-04 12:38:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2433) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-04 07:09:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:11:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:11:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:11:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:11:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:42:29 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2450
ERROR - 2020-08-04 07:13:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:13:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:13:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:15:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:15:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:21:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:21:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:21:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:22:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 07:22:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 07:36:39 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 07:36:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:36:40 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 07:40:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 07:40:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-04 08:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:22:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:22:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:22:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:22:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:22:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:24:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:24:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:24:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:25:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:25:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:25:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:27:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:27:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:28:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:28:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:28:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:28:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:31:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:31:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:40:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:40:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:40:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:43:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:43:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:43:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:44:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:44:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:44:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:48:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:49:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:49:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:49:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 14:19:41 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 08:50:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:50:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:50:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 14:20:00 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 08:51:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:51:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:51:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 14:21:40 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2375
ERROR - 2020-08-04 08:52:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:52:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:53:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:53:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:53:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:56:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 08:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 08:56:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:02:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:02:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:02:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 09:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 09:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:03:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:55:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:55:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 09:56:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 09:56:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:56:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:58:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 09:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 09:58:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:01:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:01:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:01:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:02:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:02:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:09:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 10:09:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 10:14:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:14:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:14:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 15:55:29 --> Severity: Notice --> Undefined index: result_file /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3942
ERROR - 2020-08-04 15:55:29 --> Severity: Notice --> Undefined index: extension /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3944
ERROR - 2020-08-04 15:55:29 --> Severity: Notice --> Undefined index: extension /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3945
ERROR - 2020-08-04 15:55:29 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3999
ERROR - 2020-08-04 15:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/helpers/url_helper.php 564
ERROR - 2020-08-04 10:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:25:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:25:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:25:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:25:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 15:55:53 --> Severity: Notice --> Undefined index: result_file /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3942
ERROR - 2020-08-04 15:55:53 --> Severity: Notice --> Undefined index: extension /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3944
ERROR - 2020-08-04 15:55:53 --> Severity: Notice --> Undefined index: extension /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3945
ERROR - 2020-08-04 15:55:53 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3999
ERROR - 2020-08-04 15:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/helpers/url_helper.php 564
ERROR - 2020-08-04 10:27:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:27:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:27:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 15:57:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3994
ERROR - 2020-08-04 15:57:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:3953) /home/themes91/public_html/ci/e-academy/system/helpers/url_helper.php 564
ERROR - 2020-08-04 10:34:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 16:04:42 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3994
ERROR - 2020-08-04 16:04:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:3953) /home/themes91/public_html/ci/e-academy/system/helpers/url_helper.php 564
ERROR - 2020-08-04 10:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:38:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 10:38:28 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-04 10:41:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:41:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:41:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:43:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:43:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:43:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:48:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:48:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:49:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-04 10:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 16:24:36 --> Severity: Notice --> Undefined property: Ajaxcall::$Homemodel /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3961
ERROR - 2020-08-04 16:24:36 --> Severity: error --> Exception: Call to a member function select_all_data() on null /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3961
ERROR - 2020-08-04 16:24:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-04 10:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 10:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 10:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:03:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:03:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:03:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:05:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:05:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:05:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:07:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:07:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:07:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 16:39:27 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-04 16:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-04 16:39:27 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-04 16:39:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-04 16:41:40 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-04 16:41:40 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-04 16:50:23 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-04 16:50:23 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-04 16:57:56 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 21
ERROR - 2020-08-04 16:57:56 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 97
ERROR - 2020-08-04 16:57:56 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 194
ERROR - 2020-08-04 11:38:09 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-04 11:38:13 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-04 11:38:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:38:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:38:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:39:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:39:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:39:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:45:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:45:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:47:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:47:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:47:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:50:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:50:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:50:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:51:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 11:51:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:51:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 11:59:04 --> 404 Page Not Found: Uploads/Demo
ERROR - 2020-08-04 12:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:05:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:05:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:05:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:05:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:05:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:05:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:05:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:23:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:29:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:29:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:45:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:51:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:51:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:58:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:58:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:58:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:59:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 12:59:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 12:59:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:01:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:02:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:02:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:02:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:05:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:05:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:07:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:07:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:08:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:08:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:09:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:09:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:10:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:10:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:12:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:12:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:12:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:12:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:12:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:17:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:17:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:17:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:17:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:17:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:17:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:18:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:18:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:18:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:22:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:22:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:22:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:23:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:23:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:24:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:24:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:25:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:25:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:25:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:28:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:28:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:28:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:30:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:30:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:30:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:34:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:36:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:36:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:42:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:42:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:42:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:43:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:43:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:43:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:43:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:43:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-04 13:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-04 13:44:18 --> 404 Page Not Found: Assets/js
