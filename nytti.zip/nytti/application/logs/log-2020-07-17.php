<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-17 05:39:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 05:39:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-17 05:39:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 06:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-17 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 07:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 07:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 07:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 07:15:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-17 07:15:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-17 10:21:52 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-17 10:21:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-17 10:21:52 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-17 12:51:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-17 12:51:13 --> 404 Page Not Found: api/Welcome/show_survey
