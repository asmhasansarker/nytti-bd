<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-16 05:10:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:10:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:10:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:27:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:27:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:28:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:28:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:28:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:35:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:35:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:35:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:35:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:35:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:38:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:38:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:38:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:39:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:39:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:39:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:40:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:40:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:40:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:41:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:42:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:42:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:42:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:44:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:44:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:44:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:45:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:45:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:45:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:45:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:58:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:58:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 05:59:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 05:59:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:10:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:10:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:11:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:11:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:11:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:11:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:11:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:12:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:12:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:14:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:14:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:18:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:18:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:18:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:19:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:19:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:21:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:21:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:32:38 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-16 06:32:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:32:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:32:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-16 06:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:32:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 06:32:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 06:38:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:42:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:43:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:44:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:45:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:48:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:55:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 06:57:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:18:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:18:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:18:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:25:39 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 309
ERROR - 2020-06-16 07:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:25:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:25:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:25:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:25:49 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 309
ERROR - 2020-06-16 07:27:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:27:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:27:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:27:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Only variables should be passed by reference /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 321
ERROR - 2020-06-16 07:28:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, integer given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 321
ERROR - 2020-06-16 07:28:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 322
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Only variables should be passed by reference /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 321
ERROR - 2020-06-16 07:28:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, integer given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 321
ERROR - 2020-06-16 07:28:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 322
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 304
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 308
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 309
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 310
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 311
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 312
ERROR - 2020-06-16 07:28:00 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 313
ERROR - 2020-06-16 07:28:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:28:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:31:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:32:58 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 327
ERROR - 2020-06-16 07:32:58 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 327
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 304
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 308
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 309
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 310
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 311
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 312
ERROR - 2020-06-16 07:32:58 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 313
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 304
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 308
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 309
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 310
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 311
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 312
ERROR - 2020-06-16 07:33:24 --> Severity: Notice --> Undefined offset: 2 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 313
ERROR - 2020-06-16 07:38:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:38:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:38:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:40:27 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 373
ERROR - 2020-06-16 07:40:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:40:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:40:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:40:55 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 373
ERROR - 2020-06-16 07:42:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:42:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:42:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:42:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:42:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:42:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:43:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:44:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:44:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:45:08 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 373
ERROR - 2020-06-16 07:45:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:46:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:46:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:46:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:46:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:46:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:46:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:46:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:46:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:46:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:47:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:47:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:47:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:47:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:47:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:48:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:48:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:48:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:48:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:49:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:49:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:49:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:51:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:51:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:51:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:53:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:54:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:55:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:56:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 07:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:59:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 07:59:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 07:59:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:00:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:00:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:00:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:00:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:02:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:03:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:03:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:03:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:03:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:04:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:06:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:06:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:06:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:06:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:07:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:07:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:07:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:08:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:08:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:08:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:13:50 --> Severity: Notice --> Undefined index: teach_batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1766
ERROR - 2020-06-16 08:13:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1766
ERROR - 2020-06-16 08:13:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:13:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:13:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:24:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2783) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 08:24:17 --> Severity: Compile Error --> Can't use function return value in write context /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2783
ERROR - 2020-06-16 08:24:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:24:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:24:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:24:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:24:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:24:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2783) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 08:24:22 --> Severity: Compile Error --> Can't use function return value in write context /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2783
ERROR - 2020-06-16 08:25:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:25:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:25:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:25:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2785) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 08:25:45 --> Severity: Compile Error --> Can't use function return value in write context /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2785
ERROR - 2020-06-16 08:26:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:26:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:26:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:28:01 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2784
ERROR - 2020-06-16 08:29:23 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2785
ERROR - 2020-06-16 08:31:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:2784) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 08:31:16 --> Severity: Compile Error --> Can't use function return value in write context /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2784
ERROR - 2020-06-16 08:32:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:33:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:33:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:33:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:34:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:34:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:50:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:55:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 08:57:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:57:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:57:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:59:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 08:59:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 08:59:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:01:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:03:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:03:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:10:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:10:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:10:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:10:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:10:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:10:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:11:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:20:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:20:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:20:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:20:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:21:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:21:41 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:21:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:21:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:23:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:24:20 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:24:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:24:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:26:22 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:27:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:27:30 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:29:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:29:23 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:30:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:30:39 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:30:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:30:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:30:56 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:31:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:31:57 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:32:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:32:44 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:32:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:33:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:33:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:33:13 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:35:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:35:17 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:35:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 09:35:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:36:01 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:36:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:37:20 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:38:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:40:22 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:41:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:41:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-16 09:41:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-16 09:41:27 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:42:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:42:32 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:43:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:48:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:48:42 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:49:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:49:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:49:57 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-16 09:50:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:50:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 09:51:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 10:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 10:23:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 10:23:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 10:41:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 10:46:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 10:48:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 11:14:21 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:14:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:30 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:14:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:14:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:14:58 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:16:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:16:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:16:10 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:21:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:21:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:21:25 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:27:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:27:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:27:18 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:29:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 11:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:29:52 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 11:29:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 11:30:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 11:30:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-16 11:32:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 11:32:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:32:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 11:32:44 --> 404 Page Not Found: Ajaxcall/batchdetails_table
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_start_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_end_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_start_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_end_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_start_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_end_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_start_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:33 --> Severity: Notice --> Undefined index: sub_end_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:09:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:09:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:09:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:09:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_start_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_end_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_start_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_end_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_start_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_end_time /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_start_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:09:39 --> Severity: Notice --> Undefined index: sub_end_date /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:10:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:10:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 448
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:10:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 449
ERROR - 2020-06-16 12:10:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:10:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:10:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:18:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:18:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:19:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:19:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:19:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:34:53 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 432
ERROR - 2020-06-16 12:34:53 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 432
ERROR - 2020-06-16 12:34:53 --> Query error: Unknown column 'ArrayArray' in 'where clause' - Invalid query: SELECT *
FROM batch_subjects use index (id)
WHERE `ArrayArray` IS NULL
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-16 12:34:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 12:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:34:57 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 432
ERROR - 2020-06-16 12:34:57 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 432
ERROR - 2020-06-16 12:34:57 --> Query error: Unknown column 'ArrayArray' in 'where clause' - Invalid query: SELECT *
FROM batch_subjects use index (id)
WHERE `ArrayArray` IS NULL
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-16 12:34:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-16 12:37:33 --> Query error: Unknown column 'description' in 'where clause' - Invalid query: SELECT *
FROM batch_subjects use index (id)
WHERE `teacher_id` = '4'
AND `batch_id` = '1'
AND  `description` LIKE '%n%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-16 12:46:22 --> Query error: Unknown column 'subject.id' in 'on clause' - Invalid query: SELECT `batch_subjects`.*
FROM batch_subjects use index (id)
JOIN `subjects` ON `subjects`.`subject_name` like '%h%' AND `subject`.`id` = `batch_subjects`.`subject_id`
WHERE `batch_subjects`.`teacher_id` = '4'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-16 12:46:27 --> Query error: Unknown column 'subject.id' in 'on clause' - Invalid query: SELECT `batch_subjects`.*
FROM batch_subjects use index (id)
JOIN `subjects` ON `subjects`.`subject_name` like '%hi%' AND `subject`.`id` = `batch_subjects`.`subject_id`
WHERE `batch_subjects`.`teacher_id` = '4'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-16 12:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:46:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:46:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 12:47:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 12:47:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:01:49 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:01:49 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:01:49 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:01:49 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:02:17 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:17 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:17 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:17 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:02:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:02:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:02:38 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:38 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:38 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:38 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:02:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:02:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:02:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:04:22 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:04:22 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:04:22 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:04:22 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:04:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:04:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:04:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:05:00 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:05:00 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:05:00 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:05:00 --> Severity: Warning --> Illegal string offset 'batch_name' /home/themes91/public_html/ci/e-academy/application/views/teacher/batch_details.php 88
ERROR - 2020-06-16 13:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:29:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:29:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:29:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:29:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:29:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:31:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:31:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:31:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:32:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:32:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:38:56 --> Severity: error --> Exception: syntax error, unexpected ''' (T_ENCAPSED_AND_WHITESPACE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 54
ERROR - 2020-06-16 13:39:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:39:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:39:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:02 --> Severity: error --> Exception: syntax error, unexpected ''' (T_ENCAPSED_AND_WHITESPACE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 54
ERROR - 2020-06-16 13:39:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:39:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:41:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:41:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:41:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:42:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:42:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:42:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:47:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:47:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:48 --> Severity: error --> Exception: syntax error, unexpected '$sub' (T_VARIABLE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 451
ERROR - 2020-06-16 13:47:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:47:57 --> Severity: error --> Exception: syntax error, unexpected '$sub' (T_VARIABLE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 451
ERROR - 2020-06-16 13:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:48:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:49:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:49:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:49:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:52:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:52:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:53:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-16 13:54:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-16 13:54:30 --> 404 Page Not Found: Assets/js
