<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-01 09:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:23:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:23:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-01 09:25:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-01 09:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:25:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:25:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-01 09:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:25:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:25:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-01 09:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:25:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-01 09:28:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp\www\e-academy\application\views\admin\extra_classes.php 91
