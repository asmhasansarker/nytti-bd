<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-22 10:59:51 --> Severity: Notice --> Undefined index: certificate_logo /home/themes91/public_html/ci/e-academy/application/views/admin/certificate.php 21
ERROR - 2020-08-22 05:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:33:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 05:44:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 05:44:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:44:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:44:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:44:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:46:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:46:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 05:50:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 05:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:50:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:54:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 05:54:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 06:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:18:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:18:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 06:24:17 --> 404 Page Not Found: Admin/view-certificate
ERROR - 2020-08-22 12:03:07 --> Severity: Notice --> Undefined variable: student_certificate /home/themes91/public_html/ci/e-academy/application/views/admin/view_certificate.php 175
ERROR - 2020-08-22 06:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:59:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 06:59:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 07:01:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 07:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:01:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 07:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-22 07:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:02:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-22 07:40:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-22 07:40:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
