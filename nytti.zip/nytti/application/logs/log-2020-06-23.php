<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-23 03:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:31:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:31:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:32:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:32:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:32:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:40:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:40:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:40:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:40:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:40:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:40:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:42:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:42:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:43:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:43:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:44:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:44:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:44:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:44:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:46:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:46:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:53:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:53:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:56:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:56:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:56:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:56:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:56:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:58:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:58:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:58:50 --> Query error: Unknown column 't' in 'where clause' - Invalid query: SELECT *
FROM video_lectures use index (id)
WHERE `admin_id` = '1'
AND `batch` = '1'
OR  `t` LIKE '%o%' ESCAPE '!'
OR  `n` LIKE '%e%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 03:59:32 --> Query error: Unknown column 't' in 'where clause' - Invalid query: SELECT *
FROM video_lectures use index (id)
WHERE `admin_id` = '1'
AND `batch` = '1'
AND  `title` LIKE '%y%' ESCAPE '!'
OR  `t` LIKE '%o%' ESCAPE '!'
OR  `n` LIKE '%e%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 03:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:59:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:59:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:59:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 03:59:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 03:59:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:01:01 --> Query error: Unknown column 'm' in 'where clause' - Invalid query: SELECT *
FROM video_lectures use index (id)
WHERE `admin_id` = '1'
AND `batch` = '1'
AND  `title` LIKE '%g%' ESCAPE '!'
OR  `m` LIKE '%u%' ESCAPE '!'
OR  `topic` LIKE '%nelson mondel%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 04:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:01:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 04:01:09 --> Query error: Unknown column 'm' in 'where clause' - Invalid query: SELECT *
FROM video_lectures use index (id)
WHERE `admin_id` = '1'
AND `batch` = '1'
AND  `title` LIKE '%gh%' ESCAPE '!'
OR  `m` LIKE '%u%' ESCAPE '!'
OR  `topic` LIKE '%nelson mondel%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 04:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 04:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 04:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 04:05:24 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-23 04:05:24 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-23 04:05:24 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-23 04:05:24 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-23 04:53:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 04:53:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-23 04:56:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 05:34:42 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-23 05:34:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 05:45:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:11:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:13:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:15:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:20:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:24:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:43:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:46:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:56:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 06:56:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:25:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:26:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:29:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:30:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:33:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:36:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:36:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:37:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:40:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:42:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:43:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:44:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:47:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:52:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:53:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:54:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 07:54:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:00:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:07:26 --> Severity: Notice --> Undefined variable: admin_id /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 213
ERROR - 2020-06-23 08:07:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `id` in (1,19)
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` =  AND `id` in (1,19)
ORDER BY `id` DESC
ERROR - 2020-06-23 08:07:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 08:09:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 08:09:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 08:09:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 08:38:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:40:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:40:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:41:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:42:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:46:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:50:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:53:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:54:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 08:55:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:01:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:11:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:12:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:15:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:15:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:17:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:19:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:22:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:23:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:25:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:25:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:27:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:28:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 09:29:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 10:02:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 10:07:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 10:12:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 10:15:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 10:24:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:12:52 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:12:52 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:12:52 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:12:52 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:13:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:13:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:13:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:14:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:14:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:14:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:14:53 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:14:53 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:14:53 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:14:53 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 677
ERROR - 2020-06-23 11:16:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:17:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-23 11:17:31 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-23 11:17:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:22:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:23:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:23:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:23:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:23:33 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-23 11:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:24:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:25:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-23 11:26:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:26:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:26:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:28:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:28:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:30:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:30:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:30:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:30:34 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 681
ERROR - 2020-06-23 11:30:34 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 681
ERROR - 2020-06-23 11:30:34 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 681
ERROR - 2020-06-23 11:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:37:19 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 642
ERROR - 2020-06-23 11:37:19 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:37:19 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 642
ERROR - 2020-06-23 11:37:19 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:38:25 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 643
ERROR - 2020-06-23 11:38:25 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:38:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:38:25 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 643
ERROR - 2020-06-23 11:38:25 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:38:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:38:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:38:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:38:30 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 643
ERROR - 2020-06-23 11:38:30 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:38:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:38:30 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 643
ERROR - 2020-06-23 11:38:30 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:38:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:46:15 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 648
ERROR - 2020-06-23 11:46:15 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:46:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:46:15 --> Severity: Warning --> Illegal string offset 'login_status' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 648
ERROR - 2020-06-23 11:46:15 --> Query error: Unknown column '1dmin_id' in 'where clause' - Invalid query: SELECT *
FROM students use index (id)
WHERE `1dmin_id` = 1 AND `batch_id` in (1,19) AND `status` = 1
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:46:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-23 11:47:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`batch_id=19`
ORDER BY `id` DESC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM students use index (id)
WHERE `admin_id` = 1 AND `batch_id` in (1,19) AND `status` = `1AND status=1AND login_status=1AND` `batch_id=19`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:47:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`batch_id=19`
ORDER BY `id` DESC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM students use index (id)
WHERE `admin_id` = 1 AND `batch_id` in (1,19) AND `status` = `1AND status=1AND login_status=1AND` `batch_id=19`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 11:52:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 11:52:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 11:52:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 12:17:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 12:17:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 12:17:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 12:28:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 12:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 12:28:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 12:52:46 --> Severity: Warning --> array_column(): The column key should be either a string or an integer /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 517
ERROR - 2020-06-23 13:00:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:00:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:00:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:08:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:08:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:08:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:09:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:09:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:09:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:27:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:27:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:27:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:29:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:29:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:31:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 13:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:31:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 13:39:01 --> 404 Page Not Found: Teacher/student-notice
ERROR - 2020-06-23 13:40:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1956
ERROR - 2020-06-23 13:40:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1956
ERROR - 2020-06-23 13:40:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1956
ERROR - 2020-06-23 13:40:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1956
ERROR - 2020-06-23 13:40:36 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1956
ERROR - 2020-06-23 14:46:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:46:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:46:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:46:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:47:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:47:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:47:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:47:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:47:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:53:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:53:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:53:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:54:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:54:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:54:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:54:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:54:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:57:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 14:57:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 14:57:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:29:44 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:29:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:29:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:29:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:29:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:36:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:36:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:36:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:37:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:37:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:37:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:37:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:39:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:39:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:39:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:46:54 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:47:04 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:47:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 16:47:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:47:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:47:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:49:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:50:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:50:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:54:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:55:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:55:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:55:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:55:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:55:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:58:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:59:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 16:59:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 16:59:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:00:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:00:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:00:44 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:01:14 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:01:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:01:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:02:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:02:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:02:09 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:03:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:03:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:03:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:03:30 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:05:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:05:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:05:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:05:45 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:08:27 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:10:09 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:12:01 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:12:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:12:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:12:35 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:15:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:15:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:15:23 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:30:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:30:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:30:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:30:54 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:36:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:36:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:36:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:36:39 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:37:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:37:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:37:52 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:39:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:39:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:39:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:39:29 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:40:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:40:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:40:28 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:41:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:41:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:41:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:41:56 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:43:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:43:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:43:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:43:33 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:46:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:46:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:52:32 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 17:52:32 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-23 17:52:38 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:52:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:53:40 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:53:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:53:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:55:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:55:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:55:42 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:56:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:56:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:56:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:56:18 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:56:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 17:56:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:56:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 17:56:38 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:56:49 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:58:02 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 17:59:18 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 18:02:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:02:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:02:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:02:04 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 18:02:16 --> 404 Page Not Found: Ajaxcall/leave_table
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:18 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:12:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3155
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3156
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3158
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3159
ERROR - 2020-06-23 18:12:26 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3160
ERROR - 2020-06-23 18:13:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:13:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:14:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:14:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:14:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:15:10 --> 404 Page Not Found: Teacher/undefined
ERROR - 2020-06-23 18:15:12 --> 404 Page Not Found: Teacher/undefined
ERROR - 2020-06-23 18:16:00 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `user_id` = '4'
AND  `title` LIKE '%t%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 18:16:02 --> Query error: Unknown column 'title' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `user_id` = '4'
AND  `title` LIKE '%test%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-23 18:17:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:17:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:21:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:21:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:21:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:21:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:21:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:29:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-23 18:29:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-23 18:29:01 --> 404 Page Not Found: Assets/js
