<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-30 04:51:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 04:51:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:00:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:02:42 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:05:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:05:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:06:02 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:06:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:06:09 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:06:09 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:08:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:10:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:11:21 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:12:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:12:47 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 05:12:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:15:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:17:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:18:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:20:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:21:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:24:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:26:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:28:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 05:28:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 05:28:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:30:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:31:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:47:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:48:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:52:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:53:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:55:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 05:56:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:14:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:15:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:18:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:20:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:22:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:23:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:23:07 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:27:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:27:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:27:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:27:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:27:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:27:20 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:27:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:32 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:31:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:31:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:00 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:21 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:32:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:32:41 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:42:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:42:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 06:50:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:54:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:55:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:57:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:59:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 06:59:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 07:00:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 08:49:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:07:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:09:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:43:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:52:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 09:52:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:52:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 09:58:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:00:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:00:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:00:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:00:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:00:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:02:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:02:28 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 10:03:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:04:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:04:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 10:10:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:13:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:14:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:17:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:18:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:20:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:21:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:22:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:22:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:27:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:27:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:28:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:28:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:28:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:28:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:28:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:32:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:32:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:32:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:32:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:32:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:33:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:33:05 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 10:33:10 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 10:33:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:33:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:33:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:33:25 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 10:34:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:34:22 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 10:34:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:37:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:37:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:45:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:46:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:48:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:49:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:52:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:54:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:55:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:56:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 10:59:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:01:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:01:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:02:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:02:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:03:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:03:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:04:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:27:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:29:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:30:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:34:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:35:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:36:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 17:07:22 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 506
ERROR - 2020-06-30 17:07:22 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 507
ERROR - 2020-06-30 17:07:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
ORDER BY `date` ASC' at line 5 - Invalid query: SELECT `extra_classes`.*, `users`.`name`, `users`.`teach_gender`
FROM extra_classes use index(id)
JOIN `users` ON `users`.`id` = `extra_classes`.`teacher_id`
WHERE `extra_classes`.`admin_id` = '1'
AND `extra_classes`.`added_at` > `IS` `NULL`
ORDER BY `date` ASC
ERROR - 2020-06-30 17:07:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-30 11:38:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:40:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:42:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:52:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:53:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:53:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:53:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:53:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:58:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 11:59:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:00:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:01:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:01:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:04:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:04:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:04:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:06:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:07:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:07:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:07:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:13:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:14:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:16:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:20:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:20:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:22:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:22:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:24:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:24:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:24:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:24:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:25:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:25:08 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:27:03 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:27:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:30:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:04 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:08 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:15 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:31 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:31:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:31:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:32:21 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 12:32:24 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 12:32:26 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-30 12:32:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:36:35 --> Severity: error --> Exception: syntax error, unexpected end of file /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 544
ERROR - 2020-06-30 12:37:10 --> Severity: error --> Exception: syntax error, unexpected end of file /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 544
ERROR - 2020-06-30 12:38:04 --> Severity: error --> Exception: syntax error, unexpected end of file /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 544
ERROR - 2020-06-30 18:08:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'date >= `2020-06-30`
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND added_at >= '2020-06-26 17:13:22' date >= `2020-06-30`
ORDER BY `id` DESC
ERROR - 2020-06-30 18:08:51 --> Query error: Unknown column '2020-06-30' in 'where clause' - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND `added_at` >= '2020-06-26 17:13:22' AND `date` >= `2020-06-30`
ORDER BY `id` DESC
ERROR - 2020-06-30 18:10:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'date>=CURDATE()
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND `added_at` >= '2020-06-26 17:13:22' date>=CURDATE()
ORDER BY `id` DESC
ERROR - 2020-06-30 18:11:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'date >= CURDATE()
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND (`notice_for` = 'Student' OR `notice_for` = 'Both' OR `student_id` = 2) AND added_at >= '2020-06-26 17:13:22' date >= CURDATE()
ORDER BY `id` DESC
ERROR - 2020-06-30 12:44:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:44:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:45:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:47:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:47:24 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:47:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:47:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:48:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:48:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:48:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:48:03 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:48:30 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:48:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 12:50:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 12:50:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 13:02:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 13:02:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-30 13:02:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 13:05:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 13:05:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-30 13:07:47 --> 404 Page Not Found: api/Notice/show_ads
