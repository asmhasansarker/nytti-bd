<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 05:33:16 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-17 05:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 05:34:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 05:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 05:34:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 05:34:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:13:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:13:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:13:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:15:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:15:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:16:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:16:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:18:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:18:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:18:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:26:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:26:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:28:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:28:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:36:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:36:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:36:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:36:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:36:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:37:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:37:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:37:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:54:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:54:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 06:54:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 06:54:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:06:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:06:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:07:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:07:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:07:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:07:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:07:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:07:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:09:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:09:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:09:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:10:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:10:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:10:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:24:15 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 07:24:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 07:24:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 07:24:25 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 07:24:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 07:28:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 07:28:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:28:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:28:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:30:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:30:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:30:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:31:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:31:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:31:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:33:41 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-17 07:33:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = Array
WHERE 1 IS NULL' at line 1 - Invalid query: UPDATE `frontend_details` SET `selection` = '{\"John Doe--selection.png\":\"MPPSC\",\"Nadin Parker--test1_200527064048.png\":\"SSC\"}', `selectn_heading` = 'Our Selections', `selectn_subheading` = 'TOPPERS ARE HERE', 0 = Array
WHERE 1 IS NULL
ERROR - 2020-06-17 07:33:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-17 07:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:33:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:34:02 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-17 07:34:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = Array
WHERE 1 IS NULL' at line 1 - Invalid query: UPDATE `frontend_details` SET `selection` = '{\"John Doe--selection.png\":\"MPPSC\",\"Nadin Parker--test1_200527064048.png\":\"SSC\"}', `selectn_heading` = 'Our Selections', `selectn_subheading` = 'TOPPERS ARE HERE', 0 = Array
WHERE 1 IS NULL
ERROR - 2020-06-17 07:34:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-17 07:34:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:34:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:34:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:36:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:36:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:37:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:37:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:37:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:39:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:39:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:39:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:39:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:39:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:39:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:40:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:40:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 07:40:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 07:49:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 08:00:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:00:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:00:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:01:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:01:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:01:45 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 08:01:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 08:02:00 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 08:02:00 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 08:02:00 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 08:02:00 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 08:10:41 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-17 08:10:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = Array
WHERE 1 IS NULL' at line 1 - Invalid query: UPDATE `frontend_details` SET `selection` = '{\"John Doe--selection.png\":\"MPPSC\",\"Nadin Parker--test1_200527064048.png\":\"SSC\"}', `selectn_heading` = 'Our Selections', `selectn_subheading` = 'TOPPERS ARE HERE', 0 = Array
WHERE 1 IS NULL
ERROR - 2020-06-17 08:10:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-17 08:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:10:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:10:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:18:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:18:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:24:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:24:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:24:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:39:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:39:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:39:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:39:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:39:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:39:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:40:00 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-17 08:40:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = Array
WHERE 1 IS NULL' at line 1 - Invalid query: UPDATE `frontend_details` SET `selection` = '{\"John Doe--selection.png\":\"MPPSC\",\"Nadin Parker--test1_200527064048.png\":\"SSC\"}', `selectn_heading` = 'Our Selections', `selectn_subheading` = 'TOPPERS ARE HERE', 0 = Array
WHERE 1 IS NULL
ERROR - 2020-06-17 08:40:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-17 08:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:40:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:40:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:40:10 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-17 08:40:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '0 = Array
WHERE 1 IS NULL' at line 1 - Invalid query: UPDATE `frontend_details` SET `selection` = '{\"John Doe--selection.png\":\"MPPSC\",\"Nadin Parker--test1_200527064048.png\":\"SSC\"}', `selectn_heading` = 'Our Selections', `selectn_subheading` = 'TOPPERS ARE HERE', 0 = Array
WHERE 1 IS NULL
ERROR - 2020-06-17 08:40:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-17 08:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:43:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:43:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:43:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:52:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:52:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:52:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:52:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:53:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:54:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 08:54:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 08:54:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:02:30 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 09:02:30 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 09:03:13 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 09:03:13 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 09:03:13 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 09:03:13 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 09:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:06:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:06:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:07:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:07:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:11:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:11:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:11:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:11:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:12:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:21:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:22:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:22:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:23:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:23:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:25:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:25:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:25:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:25:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:25:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:25:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:26:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:26:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:26:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:26:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:27:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:27:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:27:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:37:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:37:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:37:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:37:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:37:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:38:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:38:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:38:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:42:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:42:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:53:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:53:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:54:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:54:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:54:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:54:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:55:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 09:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 09:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:54 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:03:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:03:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:03:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:01 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:03:18 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:04:04 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:04:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:04:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:04:11 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2340
ERROR - 2020-06-17 10:07:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:07:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:07:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:07:32 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2341
ERROR - 2020-06-17 10:08:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:08:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:08:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:08:24 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2341
ERROR - 2020-06-17 10:08:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:08:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:08:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:08:47 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2341
ERROR - 2020-06-17 10:10:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:10:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:10:10 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2342
ERROR - 2020-06-17 10:10:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:10:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:15:21 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 98
ERROR - 2020-06-17 10:15:26 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 98
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:38 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:16:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:16:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:16:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:16:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:16:45 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1116
ERROR - 2020-06-17 10:17:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:17:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:17:59 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 10:17:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-17 10:18:08 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 10:18:08 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-17 10:18:08 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 10:18:08 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-17 10:23:04 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-17 10:23:04 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-17 10:23:07 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-17 10:23:07 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-17 10:31:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-17 10:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:31:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 10:32:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 10:32:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 10:32:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 10:32:16 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 10:32:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 10:33:22 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 10:33:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 10:35:15 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-17 10:35:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-17 13:39:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 13:39:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-17 13:39:26 --> 404 Page Not Found: Assets/css
