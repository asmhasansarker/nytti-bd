<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-15 11:45:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-15 11:45:07 --> 404 Page Not Found: api/Notice/show_ads
