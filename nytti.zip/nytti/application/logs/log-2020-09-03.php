<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-03 12:22:17 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-03 12:22:17 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:23:05 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:15 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
ERROR - 2020-09-03 12:29:21 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1169
