<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-27 05:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:02:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:17:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:21:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:21:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:21:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:21:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:21:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:26:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:26:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:36:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 05:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 05:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 15:56:16 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2638
ERROR - 2020-08-27 10:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 10:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 10:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 10:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 10:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 15:59:07 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-27 15:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-27 15:59:07 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-27 15:59:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-27 16:01:35 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-27 16:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-27 16:01:35 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-27 16:01:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-27 17:09:56 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2638
ERROR - 2020-08-27 11:40:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 11:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-27 11:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-27 11:40:15 --> 404 Page Not Found: Assets/js
