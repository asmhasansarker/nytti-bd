<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-19 05:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:47:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:47:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 05:48:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 05:48:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:48:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:48:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 05:48:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:48:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:49:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 05:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 05:49:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:22 --> Severity: Warning --> array_unique() expects parameter 1 to be array, integer given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 513
ERROR - 2020-06-19 06:02:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:02:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:02:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:02:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:02:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:02:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:50:23 --> Severity: Notice --> Undefined index: name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 466
ERROR - 2020-06-19 06:50:23 --> Severity: Notice --> Undefined index: name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 466
ERROR - 2020-06-19 06:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:50:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:50:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:51:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:51:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:54:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:54:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:54:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:55:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:55:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:55:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:57:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:57:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:57:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, integer given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 513
ERROR - 2020-06-19 06:59:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:59:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:59:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:59:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:59:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:59:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 06:59:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 06:59:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:04:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:04:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:04:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:04:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:05:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:05:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:22:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:22:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:25:36 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 162
ERROR - 2020-06-19 07:25:36 --> Severity: Notice --> Undefined variable: completeChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 79
ERROR - 2020-06-19 07:25:36 --> Severity: Notice --> Undefined variable: pendingChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 80
ERROR - 2020-06-19 07:26:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `subject_name`
FROM subjects use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 07:28:16 --> Severity: Notice --> Undefined variable: completeChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 79
ERROR - 2020-06-19 07:28:16 --> Severity: Notice --> Undefined variable: pendingChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 80
ERROR - 2020-06-19 07:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:31:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:31:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:32:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:32:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:32:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:32:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:32:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:37:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:37:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:38:39 --> Severity: Notice --> Undefined variable: completeChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 79
ERROR - 2020-06-19 07:38:39 --> Severity: Notice --> Undefined variable: pendingChapter /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_progress.php 80
ERROR - 2020-06-19 07:40:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:40:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:40:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:40:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:40:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:40:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:40:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:40:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:41:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:41:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:41:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:41:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:41:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:42:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:42:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:48:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:49:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:52:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:52:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 07:52:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 07:53:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:00:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:00:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:00:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:02:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:02:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:02:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:02:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:04:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:04:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:04:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:06:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:06:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:06:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:08:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:08:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:09:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:14:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') AND `mock_sheduled_date` = '2020-06-19'' at line 3 - Invalid query: SELECT COUNT(*) AS `numrows`
FROM exams use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND `type` = 1 AND `batch_id` in () AND `mock_sheduled_date` = '2020-06-19'
ERROR - 2020-06-19 08:19:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:19:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:19:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches  use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:19:27 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:19:27 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:19:30 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 08:19:30 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 08:19:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM exams use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND `batch_id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-19 08:19:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `practice_result`.`id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `practice_result`.*, `students`.`name`, `students`.`image`, `students`.`enrollment_id`
FROM practice_result use index (id)
JOIN `students` ON `students`.`id` = `practice_result`.`student_id`
WHERE `practice_result`.`admin_id` = 1 AND `students`.`batch_id` in ()
ORDER BY `practice_result`.`id` DESC
 LIMIT 10
ERROR - 2020-06-19 08:19:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `mock_result`.`id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `mock_result`.*, `students`.`name`, `students`.`image`, `students`.`enrollment_id`
FROM mock_result use index (id)
JOIN `students` ON `students`.`id` = `mock_result`.`student_id`
WHERE `mock_result`.`admin_id` = 1 AND `students`.`batch_id` in ()
ORDER BY `mock_result`.`id` DESC
 LIMIT 10
ERROR - 2020-06-19 08:19:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:20:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:20:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:20:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:20:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:20:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `mock_result`.`id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `mock_result`.*, `students`.`name`, `students`.`image`, `students`.`enrollment_id`
FROM mock_result use index (id)
JOIN `students` ON `students`.`id` = `mock_result`.`student_id`
WHERE `mock_result`.`admin_id` = 1 AND `students`.`batch_id` in ()
ORDER BY `mock_result`.`id` DESC
 LIMIT 10
ERROR - 2020-06-19 08:23:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:23:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:23:46 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2470
ERROR - 2020-06-19 08:24:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:24:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:24:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:24:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:25:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:25:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:25:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:25:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:25:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:25:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:25:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 3 - Invalid query: SELECT *
FROM exams use index (id)
WHERE `admin_id` = 1 AND `status` = 1 AND `batch_id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-19 08:28:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 08:28:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:28:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 08:30:33 --> Severity: Notice --> Undefined variable: completeChapter /home/themes91/public_html/ci/e-academy/application/views/teacher/progress.php 79
ERROR - 2020-06-19 08:30:33 --> Severity: Notice --> Undefined variable: pendingChapter /home/themes91/public_html/ci/e-academy/application/views/teacher/progress.php 80
ERROR - 2020-06-19 08:31:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 08:32:38 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:32:38 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:32:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 08:32:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 08:32:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 08:32:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 08:32:52 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:32:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 08:32:53 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 08:32:53 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 08:32:53 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 08:32:53 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 08:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `id` in ()
ORDER BY `id` DESC
ERROR - 2020-06-19 09:50:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:50:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:50:59 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:50:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:51:00 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-19 09:51:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:51:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:51:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:51:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:51:07 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:51:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:51:10 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 09:51:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:52:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:52:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:53:02 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 09:53:02 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 09:53:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 09:53:33 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 09:53:33 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 09:53:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 09:53:36 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 09:53:36 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 09:53:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 09:55:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:55:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:55:06 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 09:55:06 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 09:55:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 09:55:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 09:55:25 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 09:55:25 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 09:56:29 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-19 09:56:29 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-19 09:58:27 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 09:58:27 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 09:58:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 09:59:33 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 09:59:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 10:00:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 10:01:33 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:01:33 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:01:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:03:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 10:03:17 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:03:17 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:03:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:05:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 10:06:17 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:06:17 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:06:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:06:17 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:06:17 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:06:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:07:22 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:07:22 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:07:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:07:22 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:07:22 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '1' LIMIT 1
ERROR - 2020-06-19 10:07:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:07:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 10:15:05 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_driver.php 1519
ERROR - 2020-06-19 10:15:05 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `exams` SET `total_question` = Array
WHERE `id` = '2' LIMIT 1
ERROR - 2020-06-19 10:15:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-19 10:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 10:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-19 10:19:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-19 11:18:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 11:18:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 11:20:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 11:20:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 11:22:19 --> Severity: Notice --> Undefined variable: id /home/themes91/public_html/ci/e-academy/application/views/teacher/progress.php 92
ERROR - 2020-06-19 11:23:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 11:59:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:12:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:14:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:16:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:43:04 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 12:43:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 12:43:04 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 12:43:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 12:45:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:49:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:49:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:52:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:55:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 12:58:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:00:07 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:00:07 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:00:52 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:00:52 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:01:03 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-19 13:03:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:07:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:14:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:21:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:21:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:21:38 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:21:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:21:44 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-19 13:21:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:21:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:23:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:23:03 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:23:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:23:25 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:26:12 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:26:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:37:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:37:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:37:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:37:24 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:37:27 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-19 13:47:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:47:11 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:47:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:47:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:47:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:47:59 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:48:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:48:04 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-19 13:48:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 13:48:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-19 14:03:33 --> 404 Page Not Found: api/Notice/show_ads
