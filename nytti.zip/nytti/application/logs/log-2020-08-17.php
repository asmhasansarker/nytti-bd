<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-17 10:17:08 --> Severity: Warning --> include_once(/home/themes91/public_html/ci/e-academy/application//dompdf/autoload.inc.php): failed to open stream: No such file or directory /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 665
ERROR - 2020-08-17 10:17:08 --> Severity: Warning --> include_once(): Failed opening '/home/themes91/public_html/ci/e-academy/application//dompdf/autoload.inc.php' for inclusion (include_path='.:/opt/cpanel/ea-php72/root/usr/share/pear') /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 665
ERROR - 2020-08-17 10:17:08 --> Severity: error --> Exception: Class 'Dompdf' not found /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 666
ERROR - 2020-08-17 10:17:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-17 10:18:26 --> Severity: error --> Exception: Class 'Dompdf' not found /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 666
ERROR - 2020-08-17 10:59:38 --> Severity: Warning --> file_put_contents(/home/themes91/public_html/ci/e-academy/application/uploads/certificate/certificate_6_1.pdf): failed to open stream: No such file or directory /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 679
ERROR - 2020-08-17 11:06:38 --> Severity: Warning --> file_put_contents(/home/themes91/public_html/ci/e-academy/application/uploads/certificate/certificate_6_1.pdf): failed to open stream: No such file or directory /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 680
ERROR - 2020-08-17 11:06:55 --> Severity: Warning --> file_put_contents(/home/themes91/public_html/ci/e-academy/application/uploads/certificate/certificate_6_1.pdf): failed to open stream: No such file or directory /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 680
ERROR - 2020-08-17 11:25:48 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 432
ERROR - 2020-08-17 11:25:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:25:48 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:51:17 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 432
ERROR - 2020-08-17 11:51:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:51:17 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:55:16 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 432
ERROR - 2020-08-17 11:55:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:55:16 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:57:43 --> Severity: Warning --> mb_detect_encoding() expects parameter 1 to be string, object given /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 432
ERROR - 2020-08-17 11:57:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 11:57:43 --> Severity: Warning --> mb_convert_encoding(): Illegal character encoding specified /home/themes91/public_html/ci/e-academy/application/third_party/dompdf/src/Dompdf.php 440
ERROR - 2020-08-17 07:17:45 --> 404 Page Not Found: Uploads/students
ERROR - 2020-08-17 09:32:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:32:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:32:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:32:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-17 09:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-17 09:59:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-17 09:59:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-17 09:59:28 --> 404 Page Not Found: Assets/js
