<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-10 05:26:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 05:26:39 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-10 06:40:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 06:40:02 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-10 06:40:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 07:16:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:08:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:08:28 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-10 11:08:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:08:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:09:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:10:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:10:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:11:03 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-10 11:11:23 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-10 11:11:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-10 11:12:08 --> 404 Page Not Found: api/Notice/show_ads
