<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 17
ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 18
ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 18
ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 19
ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 20
ERROR - 2020-06-24 03:57:45 --> Severity: Notice --> Undefined variable: class /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 20
ERROR - 2020-06-24 04:05:09 --> Severity: Notice --> Undefined variable: admsnDate /home/themes91/public_html/ci/e-academy/application/views/admin/personal_notice.php 26
ERROR - 2020-06-24 04:09:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:09:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:09:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 04:12:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:12:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 04:12:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:13:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:13:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:13:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 04:14:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 04:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:14:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:33:08 --> 404 Page Not Found: Ajaxcall/student_notice_table
ERROR - 2020-06-24 04:33:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:33:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 04:33:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:26:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:26:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:26:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:26:30 --> 404 Page Not Found: Ajaxcall/student_notice_table
ERROR - 2020-06-24 05:26:41 --> 404 Page Not Found: Ajaxcall/student_notice_table
ERROR - 2020-06-24 05:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:36:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:36:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:36:23 --> 404 Page Not Found: Ajaxcall/student_notice_table
ERROR - 2020-06-24 05:57:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:57:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:57:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:57:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '! 0
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT *
FROM notices use index (id)
WHERE `admin_id` = '1'
AND student_id ! 0
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-24 05:58:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:58:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:58:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:58:07 --> Severity: Notice --> Undefined variable: student_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1517
ERROR - 2020-06-24 05:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 05:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:01:35 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/student_notice.php 78
ERROR - 2020-06-24 06:04:20 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/student_notice.php 78
ERROR - 2020-06-24 06:06:52 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/student_notice.php 78
ERROR - 2020-06-24 06:09:48 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:11:17 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:11:22 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:11:31 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:11:45 --> 404 Page Not Found: Admin/teacher-notice
ERROR - 2020-06-24 06:12:08 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:12:12 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 77
ERROR - 2020-06-24 06:27:27 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:28:03 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:28:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 06:28:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:28:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 06:28:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:29:02 --> Severity: Notice --> Undefined variable: student_data /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 47
ERROR - 2020-06-24 06:29:02 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:29:03 --> Severity: Notice --> Undefined variable: student_data /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 47
ERROR - 2020-06-24 06:29:03 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:29:32 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:29:35 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:30:13 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:30:15 --> Severity: Notice --> Undefined variable: student_id /home/themes91/public_html/ci/e-academy/application/views/admin/teacher_notice.php 94
ERROR - 2020-06-24 06:40:32 --> Severity: error --> Exception: syntax error, unexpected '$id' (T_VARIABLE), expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1572
ERROR - 2020-06-24 06:40:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:40:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:40:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 06:40:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 06:40:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:40:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:40:40 --> Severity: error --> Exception: syntax error, unexpected '$id' (T_VARIABLE), expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 1572
ERROR - 2020-06-24 06:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 06:41:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 06:59:39 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 06:59:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:00:12 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:00:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:00:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:00:16 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:00:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:27 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:47 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:01:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:01:50 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:02:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:02:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:02:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 07:02:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:42:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:42:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:42:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:15 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:51:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:51:21 --> Severity: Notice --> Undefined index: date /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 698
ERROR - 2020-06-24 07:52:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:52:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:52:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:52:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:52:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:54:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:54:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:54:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:55:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 07:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 07:55:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:01:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:01:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:01:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:02:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:02:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:08:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:08:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:11:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:11:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:11:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:21:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:21:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:21:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:24:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:24:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:24:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:25:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:25:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:26:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:26:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:26:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:26:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 08:26:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 08:26:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 09:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 09:41:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 09:41:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 09:56:11 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 09:56:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 09:56:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 09:56:23 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 09:56:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 09:56:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:34:42 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:34:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:35:33 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:35:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:36:52 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:36:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:36:56 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-24 10:37:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:37:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:37:29 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:37:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:37:33 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:37:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:38:33 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-24 10:38:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:38:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:38:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:38:41 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:38:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:38:59 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:39:12 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:39:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:39:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 10:39:25 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:30 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 10:39:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:16:12 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:16:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:16:13 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:19:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:21:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:27:37 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:27:39 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:27:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 12:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 12:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 12:28:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:28:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:29:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:31:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:32:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:34:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:34:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:34:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:34:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:34:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:35:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:35:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:35:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:36:04 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 12:36:04 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 12:36:30 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 12:36:30 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 12:40:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:40:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:43:06 --> Severity: Notice --> Undefined variable: admin_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 325
ERROR - 2020-06-24 12:49:30 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:49:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:49:40 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:49:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:49:44 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:49:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:49:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:49:47 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:49:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:49:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:50:04 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:50:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:50:51 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:50:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:51:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:51:47 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:58:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:58:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 12:58:38 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 12:58:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:00:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:11:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:13:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:14:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:15:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:17:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:18:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:18:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:20:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:21:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:22:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:22:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:23:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:23:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:24:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:24:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:24:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:27:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:27:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:27:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:27:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:28:00 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:28:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:28:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:28:04 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:28:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:28:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:28:07 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:28:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:28:32 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:28:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:29:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:29:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:29:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:29:40 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:29:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:29:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:31:36 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-24 13:31:41 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:31:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:31:48 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-24 13:31:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:31:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:32:01 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-24 13:32:05 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:32:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:33:09 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:33:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:34:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-24 13:34:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:35:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 13:37:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-24 15:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:23:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:31:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:31:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:34:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:34:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:35:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:35:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:35:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:38:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:38:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:39:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:39:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:39:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:40:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:40:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:41:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:43:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:43:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:43:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:43:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:46:58 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-24 15:46:58 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-24 15:47:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:47:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:47:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:47:12 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:47:39 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:47:39 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-24 15:47:39 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:47:39 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-24 15:50:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 15:50:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 15:50:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:17:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:17:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:20:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:20:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:20:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:21:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:22:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:22:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:22:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:23:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:23:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:23:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:24:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:24:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:24:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:27:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:27:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:27:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:27:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:27:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:27:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:30:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:30:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:35:36 --> 404 Page Not Found: Student/apply-leave
ERROR - 2020-06-24 17:36:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:36:19 --> Query error: Unknown column 'batch' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `admin_id` = '1'
AND `batch` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-24 17:37:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:37:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:37:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:37:17 --> Query error: Unknown column 'batch' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `admin_id` = '1'
AND `batch` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-24 17:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:37:44 --> Query error: Unknown column 'batch' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `admin_id` = '1'
AND `batch` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-24 17:38:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:38:28 --> Query error: Unknown column 'batch' in 'where clause' - Invalid query: SELECT *
FROM leave_management use index (user_id)
WHERE `admin_id` = '1'
AND `batch` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-24 17:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:38:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:38:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:46:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:46:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:46:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:48:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:48:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:48:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:49:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:49:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:49:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:49:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:50:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:50:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:52:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:52:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:52:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:55:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:56:00 --> 404 Page Not Found: Admin/student-leave
ERROR - 2020-06-24 17:56:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:56:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:56:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 17:58:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:58:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 17:58:24 --> 404 Page Not Found: Admin/student-leave
ERROR - 2020-06-24 18:00:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 18:00:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 18:00:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 18:00:16 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 339
ERROR - 2020-06-24 18:00:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 18:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 18:00:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 18:00:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-24 18:00:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-24 18:00:36 --> 404 Page Not Found: Assets/js
