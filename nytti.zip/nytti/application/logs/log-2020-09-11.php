<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-11 11:24:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-09-11 11:24:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 11:24:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 12:47:29 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 12:47:29 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 12:56:49 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 12:56:49 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:14:40 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:14:40 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 08:47:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 45
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 185
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 188
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:17:13 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 09:11:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 45
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 185
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 188
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 189
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:41:19 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:43:28 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-09-11 14:43:28 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-09-11 14:43:28 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-09-11 14:43:28 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-09-11 14:43:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `batches`.`admin_id` = 1 AND `batches`.`id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-09-11 14:45:15 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:45:15 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:45:15 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:45:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-09-11 14:45:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-09-11 14:45:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-09-11 14:47:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `batches`.`admin_id` = 1 AND `batches`.`id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-09-11 14:47:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/create_exam.php 183
ERROR - 2020-09-11 14:48:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-09-11 14:48:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-09-11 14:48:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-09-11 14:48:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-09-11 14:51:21 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:51:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:51:21 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:51:21 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:52:12 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:52:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:52:12 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:52:12 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:52:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-09-11 14:52:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:52:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:54:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-09-11 14:54:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:54:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:55:31 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-09-11 14:55:31 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:55:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-09-11 14:55:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-09-11 14:55:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:55:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:58:08 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-09-11 14:58:08 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:58:08 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-09-11 14:59:19 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:59:19 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:59:27 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:59:27 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:59:31 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:59:31 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:59:39 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:59:39 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
ERROR - 2020-09-11 14:59:46 --> Severity: Notice --> Undefined variable: mock_label /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 303
ERROR - 2020-09-11 14:59:46 --> Severity: Notice --> Undefined variable: mock_per /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 305
