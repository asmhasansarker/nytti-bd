<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-29 13:20:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-29 13:20:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-29 13:20:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-29 13:27:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-29 13:27:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-29 13:27:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-29 13:27:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-05-29 13:27:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-05-29 13:27:29 --> 404 Page Not Found: Assets/js
