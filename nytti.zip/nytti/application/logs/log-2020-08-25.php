<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-25 12:25:20 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-25 12:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-25 12:25:20 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-25 12:25:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-25 06:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 06:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 06:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 06:59:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 06:59:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:41:44 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::iast_query() /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 302
ERROR - 2020-08-25 09:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 14:48:34 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_query_builder.php 2442
ERROR - 2020-08-25 14:48:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `chapter_name`, `no_of_questions`
FROM chapters use index (id)
WHERE `subject_id` = Array
ORDER BY `id` DESC
ERROR - 2020-08-25 14:48:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 14:48:37 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_query_builder.php 2442
ERROR - 2020-08-25 14:48:37 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `chapter_name`, `no_of_questions`
FROM chapters use index (id)
WHERE `subject_id` = Array
ORDER BY `id` DESC
ERROR - 2020-08-25 14:48:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 14:48:38 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_query_builder.php 2442
ERROR - 2020-08-25 14:48:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `chapter_name`, `no_of_questions`
FROM chapters use index (id)
WHERE `subject_id` = Array
ORDER BY `id` DESC
ERROR - 2020-08-25 14:48:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 14:48:52 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_query_builder.php 2442
ERROR - 2020-08-25 14:48:52 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `chapter_name`, `no_of_questions`
FROM chapters use index (id)
WHERE `subject_id` = Array
ORDER BY `id` DESC
ERROR - 2020-08-25 14:48:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 14:48:53 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/system/database/DB_query_builder.php 2442
ERROR - 2020-08-25 14:48:53 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `id`, `chapter_name`, `no_of_questions`
FROM chapters use index (id)
WHERE `subject_id` = Array
ORDER BY `id` DESC
ERROR - 2020-08-25 14:48:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 09:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:23:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 09:23:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:25:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:25:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 09:25:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:26:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 09:26:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:26:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:27:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:27:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 09:27:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 09:38:22 --> 404 Page Not Found: api/Exam/video_lecture
ERROR - 2020-08-25 10:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:11:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:11:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 10:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:16:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:16:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 10:26:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:05:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:21:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:21:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:21:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:49:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:49:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:49:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:50:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:50:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:50:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:50:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:50:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:55:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:55:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:55:19 --> Severity: Notice --> Undefined variable: exam /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1224
ERROR - 2020-08-25 11:57:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:57:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:57:28 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 11:58:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:58:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 11:58:25 --> Severity: Notice --> Undefined index: paper_name /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1220
ERROR - 2020-08-25 12:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:01:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:01:14 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 12:01:14 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 12:01:14 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 12:01:14 --> Severity: Notice --> Undefined variable: action /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1230
ERROR - 2020-08-25 12:02:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:02:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:03:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:03:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:03:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:19:01 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:19:20 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:19:57 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:20:09 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:20:23 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:21:13 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:26:13 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:26:45 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1245
ERROR - 2020-08-25 12:29:53 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1246
ERROR - 2020-08-25 12:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:35:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 12:35:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 12:35:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 18:14:03 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:14:03 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:14:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 13:01:10 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-25 13:01:19 --> 404 Page Not Found: Student/answer-sheet
ERROR - 2020-08-25 18:32:40 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:32:40 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:32:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:32:45 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:32:45 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:32:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:34:17 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 144
ERROR - 2020-08-25 18:34:17 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:34:17 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:34:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:34:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 18:34:27 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 144
ERROR - 2020-08-25 18:34:27 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:34:27 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:34:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:34:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 18:34:53 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 144
ERROR - 2020-08-25 18:34:53 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:34:53 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:34:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:34:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-25 18:35:34 --> Severity: Notice --> Undefined variable: results /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 52
ERROR - 2020-08-25 18:35:34 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 53
ERROR - 2020-08-25 18:35:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `question`, `answer`, `options`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-25 18:37:49 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 56
ERROR - 2020-08-25 18:37:49 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:37:49 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:37:49 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:37:49 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:37:49 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:00 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 56
ERROR - 2020-08-25 18:38:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:00 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:31 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 56
ERROR - 2020-08-25 18:38:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:38:31 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:40:15 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 56
ERROR - 2020-08-25 18:40:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:40:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:40:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:40:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 18:40:15 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 83
ERROR - 2020-08-25 13:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 13:10:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 13:10:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 18:40:58 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 57
ERROR - 2020-08-25 18:40:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:40:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:40:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:40:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:40:58 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 13:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 13:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 13:10:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 18:42:01 --> Severity: Notice --> Undefined index: question_answer /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 57
ERROR - 2020-08-25 18:42:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:42:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:42:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:42:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:42:01 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, null given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 13:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 13:12:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 18:44:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:44:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:44:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:44:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 18:44:51 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/views/student/answer_sheet.php 84
ERROR - 2020-08-25 13:14:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-25 13:14:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-25 13:14:52 --> 404 Page Not Found: Assets/js
