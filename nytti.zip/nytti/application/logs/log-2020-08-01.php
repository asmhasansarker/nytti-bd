<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-01 05:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 05:09:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 05:09:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 05:10:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 05:10:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 05:10:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 05:59:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 05:59:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 05:59:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 06:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 06:49:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 06:49:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:00:29 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:00:29 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:00:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 07:00:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 07:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:00:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:00:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:00:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:00:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:00:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:01:33 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:01:33 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:01:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 07:01:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 07:03:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:03:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:04:15 --> Severity: Warning --> array_keys() expects parameter 1 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:04:15 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1048
ERROR - 2020-08-01 07:04:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 07:04:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php:1047) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 07:06:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:06:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:06:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:06:20 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1053
ERROR - 2020-08-01 07:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:13:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:13:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:15:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:15:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:15:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:17:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:17:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:17:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:17:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 07:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 07:17:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 08:42:38 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 08:42:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-01 08:42:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-01 08:42:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 14:13:51 --> Severity: Notice --> Undefined variable: data_arr /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 324
ERROR - 2020-08-01 14:13:51 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:13:51 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:13:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 14:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 14:14:23 --> Severity: Notice --> Undefined variable: data_arr /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 324
ERROR - 2020-08-01 14:14:23 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:14:23 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:14:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 14:14:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 14:15:54 --> Severity: Notice --> Undefined variable: data_arr /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 324
ERROR - 2020-08-01 14:15:54 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:15:54 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:15:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 14:15:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 14:16:00 --> Severity: Notice --> Undefined variable: data_arr /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 324
ERROR - 2020-08-01 14:16:00 --> Severity: Warning --> array_keys() expects parameter 1 to be array, null given /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:16:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 325
ERROR - 2020-08-01 14:16:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 3 - Invalid query: SELECT `id`, `answer`
FROM questions use index (id)
WHERE `id` in ()
ERROR - 2020-08-01 14:16:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-01 14:17:24 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 413
ERROR - 2020-08-01 14:17:24 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 414
ERROR - 2020-08-01 08:49:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 08:49:59 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 14:25:19 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 421
ERROR - 2020-08-01 14:25:19 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 422
ERROR - 2020-08-01 14:25:34 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 421
ERROR - 2020-08-01 14:25:34 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 422
ERROR - 2020-08-01 08:56:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 08:56:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 08:58:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 08:58:21 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 14:29:32 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 391
ERROR - 2020-08-01 14:29:32 --> Severity: Notice --> Undefined variable: attempted_question /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 392
ERROR - 2020-08-01 08:59:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 09:06:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 09:06:50 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 09:06:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 09:16:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 09:16:44 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 14:46:54 --> Severity: Notice --> Undefined variable: attempted_question_count /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 365
ERROR - 2020-08-01 10:03:16 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM mock_result  use index (id)
JOIN `students` ON `students`.`id`=`mock_result`.`student_id`
WHERE `paper_id` = '32'
ORDER BY `id` DESC
 LIMIT 3
ERROR - 2020-08-01 10:03:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:03:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:03:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:04:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:04:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:04:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 15:48:49 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/views/admin/dashboard.php 179
ERROR - 2020-08-01 15:48:49 --> Severity: Notice --> Undefined variable: Array /home/themes91/public_html/ci/e-academy/application/views/admin/dashboard.php 179
ERROR - 2020-08-01 15:48:49 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/views/admin/dashboard.php 179
ERROR - 2020-08-01 15:48:49 --> Severity: Notice --> Undefined variable: Array /home/themes91/public_html/ci/e-academy/application/views/admin/dashboard.php 179
ERROR - 2020-08-01 10:21:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:21:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:21:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:25:49 --> 404 Page Not Found: Uploads/students
ERROR - 2020-08-01 10:25:49 --> 404 Page Not Found: Uploads/students
ERROR - 2020-08-01 10:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:25:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:25:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:26:06 --> 404 Page Not Found: Uploads/students
ERROR - 2020-08-01 10:26:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:26:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:26:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:39:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 10:39:32 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 10:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:54:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:54:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 10:55:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 10:55:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 11:04:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 11:04:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 11:04:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 11:11:16 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-01 11:11:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 11:11:17 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 11:31:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 11:31:17 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 11:31:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-01 11:31:26 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-01 11:54:34 --> Severity: Notice --> Undefined variable: id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 24
ERROR - 2020-08-01 11:54:34 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 24
ERROR - 2020-08-01 12:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:28:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 12:28:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:32:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 12:32:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:32:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:34:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 12:34:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:41:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 12:41:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:41:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 12:45:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:05:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:05:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:05:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:12:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:12:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:12:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:14:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:14:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:14:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:17:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:17:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:17:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-01 13:17:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:17:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:22:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:22:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-01 13:22:20 --> 404 Page Not Found: Assets/css
