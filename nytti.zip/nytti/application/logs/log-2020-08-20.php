<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 190
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:18:46 --> Severity: Notice --> Undefined index: percentage /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 225
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 10:25:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 05:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:04:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:04:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:06:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:13:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:13:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:13:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:13:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:13:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:14:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:14:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:17:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:17:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:18:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:18:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:18:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:18:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:18:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:21:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:21:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:25:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:25:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:29:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:29:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:29:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:29:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:29:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:31:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:32:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:33:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:33:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:34:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:34:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:36:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:36:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:37:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:37:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:43:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:43:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 05:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:45:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:57:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 05:57:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:00:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:00:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:01:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:01:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:01:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:01:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:01:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:02:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:02:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:02:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:02:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:02:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:04:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:06:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:06:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:07:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:07:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:09:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:09:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:10:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:11:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:16:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:16:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:16:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:19:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:20:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:20:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:22:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:22:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:24:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:24:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:24:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:26:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:26:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:29:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:29:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:29:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:30:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:30:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:30:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:30:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:30:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:36 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:51 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:00:59 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:05 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:01:55 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 06:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:31:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:32:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:32:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:32:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:38 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 12:02:49 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 06:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:33:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:33:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:34:44 --> 404 Page Not Found: Ajaxcall/edit_vacancy
ERROR - 2020-08-20 06:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:37:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:37:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:38:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 06:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 06:38:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 12:10:16 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-20 12:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-20 12:10:16 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-20 12:10:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-20 06:43:43 --> 404 Page Not Found: Ajaxcall/edit_vacancy
ERROR - 2020-08-20 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:04:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:04:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:05:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:05:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:05:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:05:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:05:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 12:42:47 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 12:42:47 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 12:42:58 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 12:42:58 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 12:43:14 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 12:43:14 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 12:44:02 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 12:44:02 --> Severity: Notice --> Undefined variable: android_key /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 07:16:56 --> 404 Page Not Found: Ajaxcall/add_live_class_Android
ERROR - 2020-08-20 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:22:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:22:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:22:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:23:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:23:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:24:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 07:24:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 07:24:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 12:59:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 12:59:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 13:00:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 13:00:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 13:00:22 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 100
ERROR - 2020-08-20 13:00:22 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 13:01:58 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/views/admin/live_class.php 106
ERROR - 2020-08-20 15:11:05 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-20 15:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-20 15:11:05 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-20 15:11:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-20 15:21:06 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2972
ERROR - 2020-08-20 09:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:51:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:51:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 15:26:40 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2972
ERROR - 2020-08-20 15:29:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2972
ERROR - 2020-08-20 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 09:59:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 09:59:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 15:29:35 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 2972
ERROR - 2020-08-20 09:59:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 09:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 09:59:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:00:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:00:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:00:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:00:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:00:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 10:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 10:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:02:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:05:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:05:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 10:06:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 10:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 10:06:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:06:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-20 10:13:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:46:50 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: wrongCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
ERROR - 2020-08-20 22:48:20 --> Severity: Notice --> Undefined variable: rightCount /home/themes91/public_html/ci/e-academy/application/views/student/dashboard.php 289
