<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 10:35:10 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 10:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 10:36:08 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 10:36:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 10:36:08 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 10:36:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 91
ERROR - 2020-06-27 05:09:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:11:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 05:11:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:12:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:12:20 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 10:42:31 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 10:42:31 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 05:14:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:14:47 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 10:44:48 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 10:44:48 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 05:14:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 05:14:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:44:54 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 10:44:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-06-27 05:15:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:16:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:16:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:17:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:17:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:17:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 05:22:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 05:22:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 05:23:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 05:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 05:23:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 05:25:15 --> 404 Page Not Found: Student/view-progress
ERROR - 2020-06-27 05:26:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:27:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:27:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:27:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:27:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:33:34 --> 404 Page Not Found: Student/view-progress
ERROR - 2020-06-27 05:36:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:37:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:39:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:42:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:44:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:49:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:54:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 05:58:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:28:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:28:22 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 06:34:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:34:23 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 06:41:48 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 06:41:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:42:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:43:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:44:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:46:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:46:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:47:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:48:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:49:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 06:59:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:00:00 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:00:00 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:00:00 --> Query error: Table 'themes91_eacademy.id' doesn't exist - Invalid query: SELECT *
FROM `mock_result`
JOIN `id` USING (`desc`)
WHERE `student_id` = '2'
AND `admin_id` = '1'
GROUP BY `2020-06`
ORDER BY `id` DESC
ERROR - 2020-06-27 07:00:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 07:02:35 --> Query error: Table 'themes91_eacademy.id' doesn't exist - Invalid query: SELECT *
FROM `mock_result`
JOIN `id` USING (`desc`)
WHERE `student_id` = '2'
AND `admin_id` = '1'
ORDER BY `id` DESC
ERROR - 2020-06-27 07:02:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:03:16 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 25
ERROR - 2020-06-27 07:03:16 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 25
ERROR - 2020-06-27 07:03:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'USING ()
WHERE `student_id` = '2'
AND `admin_id` = '1'
ORDER BY `id` DESC' at line 3 - Invalid query: SELECT *
FROM `practice_result`
JOIN  USING ()
WHERE `student_id` = '2'
AND `admin_id` = '1'
ORDER BY `id` DESC
ERROR - 2020-06-27 07:03:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 07:03:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:04:07 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:04:07 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:04:07 --> Query error: Table 'themes91_eacademy.id' doesn't exist - Invalid query: SELECT *
FROM `mock_result`
JOIN `id` USING (`desc`)
WHERE `student_id` = '2'
AND `admin_id` = '1'
GROUP BY `2020-06`
ORDER BY `id` DESC
ERROR - 2020-06-27 07:04:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php:158) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 07:04:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:04:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:04:37 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:04:37 --> Query error: Table 'themes91_eacademy.id' doesn't exist - Invalid query: SELECT *
FROM `mock_result`
JOIN `id` USING (`desc`)
WHERE `student_id` = '2'
AND `admin_id` = '1'
GROUP BY `2020-06`
ORDER BY `id` DESC
ERROR - 2020-06-27 07:04:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 07:05:11 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:05:11 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:05:11 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:05:11 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:05:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:05:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 07:05:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:06:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:07:07 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:07:07 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:07:07 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:07:07 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 12:37:07 --> Severity: Notice --> Undefined variable: baseurl /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 1
ERROR - 2020-06-27 12:37:07 --> Severity: Notice --> Undefined property: CI_Loader::$Homemodel /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:37:07 --> Severity: error --> Exception: Call to a member function getcatename() on null /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:37:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 07:07:35 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:07:35 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 12:37:35 --> Severity: Notice --> Undefined variable: baseurl /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 1
ERROR - 2020-06-27 12:37:35 --> Severity: Notice --> Undefined property: CI_Loader::$Homemodel /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:37:35 --> Severity: error --> Exception: Call to a member function getcatename() on null /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:37:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 12:37:56 --> Severity: Notice --> Undefined variable: baseurl /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 1
ERROR - 2020-06-27 12:37:56 --> Severity: Notice --> Undefined property: CI_Loader::$Homemodel /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:37:56 --> Severity: error --> Exception: Call to a member function getcatename() on null /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:38:59 --> Severity: Notice --> Undefined property: CI_Loader::$Homemodel /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 12:38:59 --> Severity: error --> Exception: Call to a member function getcatename() on null /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 265
ERROR - 2020-06-27 07:09:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:10:19 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 47
ERROR - 2020-06-27 07:10:19 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:11:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:12:11 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 48
ERROR - 2020-06-27 07:12:11 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 49
ERROR - 2020-06-27 07:12:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:13:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:13:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 12:48:54 --> Severity: Notice --> Undefined variable: role /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 240
ERROR - 2020-06-27 12:48:54 --> Severity: Notice --> Undefined variable: role /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 240
ERROR - 2020-06-27 12:48:54 --> Severity: Notice --> Undefined property: CI_Loader::$Homemodel /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 254
ERROR - 2020-06-27 12:48:54 --> Severity: error --> Exception: Call to a member function getcatename() on null /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 254
ERROR - 2020-06-27 07:29:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:29:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:29:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 07:31:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:31:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:31:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 07:32:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:34:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 07:34:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:34:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 07:35:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 07:35:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:11:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:11:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:11:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:13:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:13:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:33:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:33:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 14:03:23 --> Severity: error --> Exception: syntax error, unexpected ')' /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 138
ERROR - 2020-06-27 14:03:26 --> Severity: error --> Exception: syntax error, unexpected ')' /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 138
ERROR - 2020-06-27 08:34:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:34:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:34:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:34:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:38:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:38:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:39:05 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 08:39:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:39:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 08:42:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:44:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:46:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:47:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:50:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 08:53:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:06:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:06:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:10:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:14:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:18:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:21:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:30:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:31:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:31:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:33:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:34:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:40:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:42:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:43:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:44:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:45:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:46:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:50:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:52:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:55:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 09:55:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:05:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:19:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:21:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:24:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:27:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:29:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:29:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:29:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:29:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:29:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:29:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:29:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:30:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:30:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:30:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:30:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:30:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:33:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 10:33:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:33:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 10:42:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 10:43:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 11:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:03:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:03:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:04:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:04:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:04:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:04:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:04:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:04:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 16:35:03 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/views/student/view_progress.php 195
ERROR - 2020-06-27 11:05:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:05:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:05:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:05:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:05:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:06:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:06:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:07:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:07:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:08:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 11:08:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:08:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 11:12:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-27 11:12:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 11:14:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 11:15:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 16:47:00 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-27 16:47:00 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-27 16:47:01 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-27 16:47:01 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-27 16:47:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-27 16:47:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-27 11:17:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-27 16:47:25 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-27 16:47:25 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-27 11:23:52 --> 404 Page Not Found: Teacher/student-academic-record
ERROR - 2020-06-27 11:28:11 --> 404 Page Not Found: Teacher/student-academic-record
ERROR - 2020-06-27 11:28:46 --> 404 Page Not Found: Teacher/academic-record
ERROR - 2020-06-27 17:13:25 --> Severity: Notice --> Undefined variable: meeting /home/themes91/public_html/ci/e-academy/application/views/teacher/live_class.php 17
ERROR - 2020-06-27 17:13:25 --> Severity: Notice --> Undefined variable: meeting /home/themes91/public_html/ci/e-academy/application/views/teacher/live_class.php 24
ERROR - 2020-06-27 11:43:33 --> 404 Page Not Found: Teacher/academic-record
ERROR - 2020-06-27 11:45:56 --> 404 Page Not Found: Admin/teacher-academic-record
ERROR - 2020-06-27 11:50:59 --> 404 Page Not Found: Teacher/academic-record
ERROR - 2020-06-27 17:22:19 --> Severity: Notice --> Undefined variable: meeting /home/themes91/public_html/ci/e-academy/application/views/teacher/live_class.php 17
ERROR - 2020-06-27 17:22:19 --> Severity: Notice --> Undefined variable: meeting /home/themes91/public_html/ci/e-academy/application/views/teacher/live_class.php 24
ERROR - 2020-06-27 11:53:51 --> 404 Page Not Found: Student/academic-record
ERROR - 2020-06-27 11:54:10 --> 404 Page Not Found: Student/academic-record
ERROR - 2020-06-27 11:54:30 --> 404 Page Not Found: Student_profile/academic_record
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:57:36 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:01 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 17:59:25 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:00:03 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:22:18 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: practice_result /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:30 --> Severity: Notice --> Undefined variable: mock_result /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 54
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 72
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: practice_result /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:46:31 --> Severity: Notice --> Undefined variable: mock_result /home/themes91/public_html/ci/e-academy/application/views/student/academic_record.php 116
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: practice_result /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 18:54:29 --> Severity: Notice --> Undefined variable: mock_result /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:01:46 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 13:35:51 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `video_lectures`
WHERE `admin_id` = '1'
AND `added_by` = '4'
AND  `date` LIKE '%2020-06-%' ESCAPE '!'
AND  `date` LIKE '%2020-06-%' ESCAPE '!'
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:06:17 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 13:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 13:38:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 13:38:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 13:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 13:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 13:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:18:03 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:18:04 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:19 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:24 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: month /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 54
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: year /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 72
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: extra_class /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: homework /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:20:26 --> Severity: Notice --> Undefined variable: video_lecture /home/themes91/public_html/ci/e-academy/application/views/teacher/academic_record.php 116
ERROR - 2020-06-27 19:29:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:29:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:29:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:29:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:29:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:29:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:30:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:30:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:31:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:31:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:33:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:33:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:33:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:33:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:35:37 --> 404 Page Not Found: Ajaxcall/get_student_name
ERROR - 2020-06-27 19:35:39 --> 404 Page Not Found: Ajaxcall/get_student_name
ERROR - 2020-06-27 19:35:39 --> 404 Page Not Found: Ajaxcall/get_student_name
ERROR - 2020-06-27 19:35:41 --> 404 Page Not Found: Ajaxcall/get_student_name
ERROR - 2020-06-27 19:36:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:36:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:38:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:38:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:38:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:40:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:40:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:41:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:59:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:59:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:59:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:59:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php:3561) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-27 19:59:10 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3561
ERROR - 2020-06-27 19:59:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 19:59:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 19:59:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:00:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:00:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:08:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:08:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:08:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:12:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:12:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:12:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:12:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:12:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:12:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:13:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:13:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:13:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:18:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:18:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:18:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:23:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:23:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:24:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:24:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:24:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:24:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:24:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:27:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:27:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:27:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:28:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:28:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:29:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:29:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:30:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:30:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:31:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:31:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:32:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:32:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:32:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:33:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:33:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:33:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:35:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:35:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:35:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:36:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:36:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:36:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:37:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:38:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:38:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:39:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:39:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:39:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:02 --> Severity: error --> Exception: syntax error, unexpected ':', expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3566
ERROR - 2020-06-27 20:41:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:41:25 --> Severity: error --> Exception: syntax error, unexpected ':', expecting ')' /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3566
ERROR - 2020-06-27 20:41:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-27 20:41:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-27 20:41:53 --> 404 Page Not Found: Assets/js
