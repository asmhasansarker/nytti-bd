<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 04:59:57 --> 404 Page Not Found: Assets/js
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-05 04:59:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-05 04:59:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-05 04:59:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-05 04:59:58 --> 404 Page Not Found: Assets/css
