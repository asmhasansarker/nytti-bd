<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-31 14:44:41 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-08-31 14:44:41 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-08-31 14:44:41 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-08-31 14:44:41 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-08-31 15:12:59 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-08-31 15:12:59 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-08-31 15:12:59 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-08-31 15:12:59 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-08-31 15:17:51 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:17:51 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:17:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-08-31 15:17:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-08-31 15:17:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-08-31 15:17:57 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-08-31 15:18:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `batches`.`admin_id` = 1 AND `batches`.`id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-08-31 15:18:33 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:18:33 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:19:11 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-31 15:19:11 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:19:11 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-31 15:20:03 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-08-31 15:20:03 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-08-31 15:20:03 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-08-31 15:20:03 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-08-31 15:20:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `batches`.`admin_id` = 1 AND `batches`.`id` in ()
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-08-31 15:20:52 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 54
ERROR - 2020-08-31 15:20:52 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 56
ERROR - 2020-08-31 15:20:52 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 58
ERROR - 2020-08-31 15:20:52 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 60
ERROR - 2020-08-31 15:36:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
ORDER BY `id` DESC
 LIMIT 10' at line 4 - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `batches`.`admin_id` = 1 AND `batches`.`id` in ()
ORDER BY `id` DESC
 LIMIT 10
