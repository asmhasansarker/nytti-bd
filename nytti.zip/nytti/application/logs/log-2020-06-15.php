<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-15 05:03:27 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 05:03:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:28:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:29:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:29:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:29:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:29:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:29:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:34:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:34:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 05:35:06 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 05:35:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:54:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:57:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 05:59:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:00:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:02:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:18:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:18:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:19:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:19:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:20:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:20:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:20:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:23:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:24:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:24:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:26:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:26:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:26:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:28:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:28:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:28:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:29:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:29:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:29:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:33:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:33:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:33:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:37:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:37:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:38:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:38:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:38:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:41:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:41:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:42:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:42:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:42:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:44:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:44:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:44:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:45:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:45:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:45:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:45:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:45:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:46:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:46:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:46:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:48:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:48:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:48:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:48:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:48:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:49:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:49:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:50:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:50:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:52:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:52:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:53:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:53:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:53:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:55:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:55:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:56:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:58:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 06:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 06:58:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:02:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:02:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:04:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:04:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:04:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:05:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:05:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:05:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:06:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:06:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:08:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:14:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:15:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:16:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:24:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:24:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:26:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:26:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:26:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:26:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:26:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:27:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:28:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:28:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:28:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:28:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:28:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:29:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:29:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:29:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:29:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:29:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:30:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:31:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:31:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:34:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:35:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:35:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:35:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:35:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:35:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 07:35:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:35:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 07:41:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:42:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:44:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:45:18 --> 404 Page Not Found: Uploads/students
ERROR - 2020-06-15 07:45:18 --> 404 Page Not Found: Uploads/students
ERROR - 2020-06-15 07:45:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:45:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 07:45:22 --> 404 Page Not Found: Uploads/students
ERROR - 2020-06-15 07:45:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 07:45:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:47:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 07:47:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:57:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:58:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 07:58:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:01:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:01:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:04:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:04:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:04:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:06:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:06:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:06:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:07:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:07:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:07:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:07:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:07:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:09:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:09:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:11:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:11:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:12:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:12:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:13:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:13:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:14:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:16:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:16:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:16:05 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:16:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:16:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:17:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:17:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:17:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:17:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:17:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:17:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:19:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:19:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:19:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:20:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:20:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:20:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:20:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:20:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:20:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:21:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:21:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:21:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:23:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:23:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:23:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:25:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:25:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:25:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:26:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:26:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:31:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:31:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:31:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:36:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:37:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:38:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:39:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:39:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:45:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:48:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 08:48:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 08:49:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:51:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:52:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:56:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:56:32 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 08:56:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:01:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:02:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:03:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:09:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:11:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:11:23 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 138
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:11 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'id' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:28 --> Severity: Warning --> Illegal string offset 'subject_name' /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 72
ERROR - 2020-06-15 09:13:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:13:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:13:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:14:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:17:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:19:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:28:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:32:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:32:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:33:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:33:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:34:03 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-15 09:35:01 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-06-15 09:36:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:37:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:37:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:37:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:37:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:40:40 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-15 09:41:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:41:48 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-15 09:41:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:00 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-15 09:42:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:45 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-15 09:42:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:42:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:53:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:55:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:55:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 09:59:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:02:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:05:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:05:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:05:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:05:18 --> 404 Page Not Found: api/Book/educationalVideo
ERROR - 2020-06-15 10:05:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:08:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:10:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:13:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:13:34 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 10:17:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:18:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:18:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:19:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:19:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 10:23:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'teach_subject' at line 3 - Invalid query: SELECT `id`, `name`
FROM users use index (id)
WHERE 1in teach_subject
ERROR - 2020-06-15 10:24:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'teach_subject' at line 3 - Invalid query: SELECT `id`, `name`
FROM users use index (id)
WHERE 1in teach_subject
ERROR - 2020-06-15 10:24:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:24:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:24:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:25:02 --> Query error: FUNCTION themes91_eacademy.1in does not exist - Invalid query: SELECT `id`, `name`
FROM users use index (id)
WHERE 1in (teach_subject)
ERROR - 2020-06-15 10:27:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:27:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:35:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:35:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:36:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:36:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:36:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:36:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:36:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:37:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 10:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:37:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 10:49:34 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:03:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:04:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:04:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:04:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 11:12:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 12:04:26 --> Severity: error --> Exception: Call to undefined function array_in() /home/themes91/public_html/ci/e-academy/application/views/admin/add_batch.php 98
ERROR - 2020-06-15 12:08:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:08:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:08:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:09:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:09:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:36:16 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 12:36:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 12:36:30 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 12:36:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 12:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:40:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:40:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:41:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:41:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 12:41:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 12:42:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:42:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:44:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:44:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:44:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:44:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:45:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:45:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:46:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:46:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:46:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:47:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:47:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:49:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:49:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:49:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:55:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:55:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:55:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:57:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 12:57:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 12:57:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:19:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:20:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:20:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:22:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 13:22:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 13:22:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 13:22:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-06-15 13:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:28:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:28:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:28:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:28:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:28:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:28:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:30:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:30:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:31:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:31:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:33:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:34:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 13:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:34:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:37:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-15 13:37:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-15 17:19:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 17:19:01 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-06-15 17:19:01 --> 404 Page Not Found: api/Notice/show_ads
