<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-01 05:13:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:13:15 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 05:21:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:21:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 05:21:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:21:40 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 05:29:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:29:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 05:30:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:38:20 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:38:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:38:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 05:40:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:40:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:40:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:41:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 05:41:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 06:36:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 06:50:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 07:12:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 07:16:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:49:44 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 12:49:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 07:20:22 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 07:20:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:50:29 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 12:50:29 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 07:31:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 07:35:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 07:38:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:27:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:28:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:28:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:35:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:37:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:38:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:40:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:58:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 08:59:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:14:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:17:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:19:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:20:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:22:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:27:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:28:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:36:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:37:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:45:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:47:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 09:49:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 10:02:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 10:14:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 11:17:19 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 100
ERROR - 2020-07-01 11:17:26 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 100
ERROR - 2020-07-01 11:17:31 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 100
ERROR - 2020-07-01 11:20:39 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 81
ERROR - 2020-07-01 11:21:51 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:23:44 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:24:00 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:25:27 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:25:41 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:26:14 --> Severity: Warning --> Use of undefined constant base_ - assumed 'base_' (this will throw an Error in a future version of PHP) /home/themes91/public_html/ci/e-academy/application/views/teacher/start_live_class.php 83
ERROR - 2020-07-01 11:39:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-01 11:39:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-01 11:39:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-01 12:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-01 12:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-01 12:27:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-01 12:52:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:57:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 12:57:50 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 12:57:50 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:58:15 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 12:58:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:58:16 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 12:58:52 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 12:58:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 18:28:54 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 18:28:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 12:59:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 18:29:02 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 18:29:02 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 12:59:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 12:59:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:00:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:01:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:01:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:01:15 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:02:49 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-01 13:03:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:03:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:03:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:04:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:04:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:04:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 18:35:05 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 18:35:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 18:35:05 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 18:35:05 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-01 13:06:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:08:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:08:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:08:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:10:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:11:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:12:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:13:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:13:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:15:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-01 13:15:22 --> 404 Page Not Found: api/Notice/show_ads
