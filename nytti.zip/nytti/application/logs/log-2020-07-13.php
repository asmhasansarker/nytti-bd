<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-13 05:21:53 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:22:23 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:22:52 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 10:54:21 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 05:34:51 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:34:53 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:34:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:34:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:35:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:35:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:36:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:36:02 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:36:56 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:36:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:37:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:37:11 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:37:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:37:19 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:38:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:38:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:38:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:38:37 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:38:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:08:48 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:51 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:51 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:51 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:52 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:52 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:52 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:53 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:08:54 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:09:12 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:09:12 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:09:12 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 05:39:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:39:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:39:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:41:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:41:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:42:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:42:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:43:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:43:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:43:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:43:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:44:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:45:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:45:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:45:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:45:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:45:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:45:59 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:46:42 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-13 05:46:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:17:16 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:17 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:17 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:17 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:17 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:17 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:18 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:18 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:18 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:17:18 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 05:47:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:47:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:47:57 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:47:57 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:47:58 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:18:07 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:09 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:10 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:11 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:12 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:12 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:13 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:13 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 11:18:13 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 05:48:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:48:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:48:47 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 05:48:54 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 05:48:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 05:48:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 06:01:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 06:01:03 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 09:05:11 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 09:05:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:05:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 09:05:25 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 09:05:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:11:31 --> 404 Page Not Found: Admin/index
ERROR - 2020-07-13 09:12:37 --> 404 Page Not Found: Admin/index
ERROR - 2020-07-13 09:12:42 --> 404 Page Not Found: Admin/index
ERROR - 2020-07-13 09:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 09:23:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 09:23:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 09:25:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 09:25:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 09:25:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 09:54:23 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 09:54:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:56:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:56:35 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 09:56:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:56:43 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 15:26:48 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:49 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:50 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 15:26:51 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 331
ERROR - 2020-07-13 09:56:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 09:56:55 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 10:13:14 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 10:13:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 16:29:50 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-13 16:30:03 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-13 11:29:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:29:34 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:30:16 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:31:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:31:57 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:32:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:32:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:32:42 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:33:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:33:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:33:35 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-13 11:33:35 --> 404 Page Not Found: api/Book/viewVacancyImage
ERROR - 2020-07-13 11:34:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:38:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:38:45 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 11:38:46 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:38:59 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-13 11:38:59 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:39:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:39:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 11:39:03 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:39:03 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-13 11:40:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-13 12:48:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 12:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:48:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:48:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 12:48:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:48:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 12:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:54:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:56:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 12:56:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:56:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:58:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 12:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 12:58:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:02:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 13:02:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:02:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:05:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:05:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:05:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 13:09:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 13:09:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:09:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:10:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-13 13:10:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-13 13:10:43 --> 404 Page Not Found: Assets/js
