<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-06 04:52:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 04:52:56 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 04:54:29 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 04:54:29 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 04:54:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:03:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:03:29 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:12:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 10:43:24 --> Severity: Notice --> Undefined variable: total_leave_pending /home/themes91/public_html/ci/e-academy/application/views/teacher/dashboard.php 96
ERROR - 2020-08-06 05:15:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:15:13 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:17:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:17:07 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:17:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:17:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:17:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:22:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:22:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:22:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:31:23 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::lasr_query() /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 36
ERROR - 2020-08-06 05:31:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:31:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:31:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:32:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:32:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:33:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:33:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:33:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:35:07 --> Severity: Notice --> Array to string conversion /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 254
ERROR - 2020-08-06 05:35:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:35:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:35:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:35:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:35:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:36:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:36:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:38:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:38:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:38:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:39:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:39:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:39:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:44:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:44:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:50:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:50:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:52:39 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:52:39 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:54:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:54:26 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 05:57:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:57:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:57:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:57:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 05:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:57:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 05:57:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 05:57:28 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:02:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:02:04 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:04:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:04:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:14:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:14:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 06:15:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:15:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:15:28 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::last_qury() /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 48
ERROR - 2020-08-06 06:16:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:16:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:16:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 06:16:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:16:44 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:18:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 06:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:18:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 06:19:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:19:01 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:21:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:21:24 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:22:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:22:19 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:30:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:30:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:33:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:33:44 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:37:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:37:49 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:45:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:45:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:48:42 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:48:42 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:51:47 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:51:47 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:56:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:56:21 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 06:57:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 06:57:14 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:02:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:02:21 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:03:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:03:05 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 12:34:54 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-06 12:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-08-06 12:34:54 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-06 12:34:54 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 104
ERROR - 2020-08-06 07:05:46 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:05:46 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-06 07:05:47 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:09:33 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-08-06 07:09:33 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:09:33 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:09:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:09:46 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:14:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:14:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:15:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:15:54 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:18:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:18:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:18:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:18:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:21:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:21:40 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:22:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:22:54 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:23:44 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:23:44 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:23:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:23:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:24:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:24:21 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 07:35:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:35:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 07:35:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 07:37:02 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-08-06 07:37:02 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 13:53:46 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 14
ERROR - 2020-08-06 13:53:46 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 123
ERROR - 2020-08-06 13:53:46 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 211
ERROR - 2020-08-06 13:53:46 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-08-06 13:56:59 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1023
ERROR - 2020-08-06 13:56:59 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 947
ERROR - 2020-08-06 08:27:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:27:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:27:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 08:27:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 08:27:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:27:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 13:57:26 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1023
ERROR - 2020-08-06 13:57:26 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 947
ERROR - 2020-08-06 08:31:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 08:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:31:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:33:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 08:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:33:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:40:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 08:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 08:40:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 14:20:46 --> Severity: Notice --> Undefined variable: new /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 1027
ERROR - 2020-08-06 14:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/controllers/Front_ajax.php 947
ERROR - 2020-08-06 09:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:08:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:08:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 09:08:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 09:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:08:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:08:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 09:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:08:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:16:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:16:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 09:16:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:22:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:22:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:22:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:22:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:30:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:30:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:30:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:30:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:13:39 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:13:39 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:13:43 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:13:43 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:13:56 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:13:56 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 10:44:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:44:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:44:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:44:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:44:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:44:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:44:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:44:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:14:06 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 16:14:06 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 472
ERROR - 2020-08-06 10:47:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:47:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:17:21 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 16:17:21 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 10:47:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:47:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:47:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:47:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:17:59 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 16:17:59 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 10:48:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:48:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:18:33 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 474
ERROR - 2020-08-06 16:18:33 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 474
ERROR - 2020-08-06 10:50:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:50:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:20:57 --> Severity: Notice --> Undefined offset: 5 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 474
ERROR - 2020-08-06 16:20:57 --> Severity: Notice --> Undefined offset: 6 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 474
ERROR - 2020-08-06 10:52:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:52:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:22:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 471
ERROR - 2020-08-06 16:22:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 471
ERROR - 2020-08-06 16:22:28 --> Severity: Warning --> array_key_exists() expects parameter 2 to be array, string given /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 471
ERROR - 2020-08-06 10:53:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:53:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 16:23:27 --> Severity: Notice --> Undefined variable: temp_cha_id /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 16:23:27 --> Severity: Notice --> Undefined index:  /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 473
ERROR - 2020-08-06 10:56:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:56:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:56:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:56:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:57:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:57:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 10:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 10:58:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:07:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:07:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:10:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:10:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:12:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:12:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:14:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:14:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:14:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:14:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:21:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:21:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:21:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:21:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:24:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:24:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:24:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:24:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:30:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:30:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:31:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:31:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:34:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:41:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:41:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:44:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:44:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:44:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:44:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 17:27:15 --> Severity: Notice --> Undefined variable: table /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3559
ERROR - 2020-08-06 17:27:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%m%' ESCAPE '!'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `users`.`name`
FROM `leave_management`
JOIN `users` ON `leave_management`.`teacher_id` = `users`.`id`
WHERE `teacher_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  .`name` LIKE '%m%' ESCAPE '!'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-08-06 17:27:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-06 11:57:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:57:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:57:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:57:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 17:27:26 --> Severity: Notice --> Undefined variable: table /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3559
ERROR - 2020-08-06 17:27:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'LIKE '%m%' ESCAPE '!'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10' at line 6 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `users`.`name`
FROM `leave_management`
JOIN `users` ON `leave_management`.`teacher_id` = `users`.`id`
WHERE `teacher_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  .`name` LIKE '%m%' ESCAPE '!'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-08-06 17:27:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-08-06 11:57:29 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-08-06 11:57:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 11:57:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:57:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:57:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 17:27:57 --> Query error: Unknown column 'users.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `teacher_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
ERROR - 2020-08-06 17:29:18 --> Query error: Unknown column 'users.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `teacher_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
ERROR - 2020-08-06 11:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:59:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 11:59:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 17:29:24 --> Query error: Unknown column 'users.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `teacher_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `users`.`name` LIKE '%mo%' ESCAPE '!'
AND  `users`.`name` LIKE '%mo%' ESCAPE '!'
ERROR - 2020-08-06 12:01:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:01:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:10:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:10:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:10:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:10:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:14:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:14:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:19:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:23:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:23:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:24:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:24:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:24:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:24:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:33:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:33:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:35:43 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:35:43 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:35:43 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:36:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:36:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:36:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:36:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:36:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:36:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:36:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:36:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:36:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:37:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:37:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:37:15 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:38:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:38:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:38:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:38:22 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:38:22 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:38:22 --> 404 Page Not Found: Undefined/index
ERROR - 2020-08-06 12:39:31 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:39:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:41:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:41:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 18:16:03 --> Severity: error --> Exception: syntax error, unexpected ''</option>'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 19
ERROR - 2020-08-06 12:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:48:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:48:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:51:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:51:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:52:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-06 12:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 12:52:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 18:25:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-06 18:25:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-06 18:25:40 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 257
ERROR - 2020-08-06 13:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 13:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 13:07:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-06 13:07:14 --> 404 Page Not Found: Assets/css
