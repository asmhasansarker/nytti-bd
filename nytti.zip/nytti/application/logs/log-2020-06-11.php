<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-11 07:17:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 07:17:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 07:17:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-11 07:26:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-11 07:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 07:26:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 07:27:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-11 07:27:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 07:27:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-11 09:50:45 --> 404 Page Not Found: Admin/x
