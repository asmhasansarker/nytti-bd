<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 10:32:44 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 10:32:47 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 10:32:48 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 10:46:33 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 10:46:37 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:56:13 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 106
ERROR - 2020-08-12 10:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 106
ERROR - 2020-08-12 10:56:13 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 10:56:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 10:56:18 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 260
ERROR - 2020-08-12 10:56:18 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 260
ERROR - 2020-08-12 10:56:18 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 260
ERROR - 2020-08-12 05:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:39:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:39:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:39:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:39:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:54:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:55:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:55:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:56:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:56:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:56:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:58:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:58:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:58:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:58:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:59:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 05:59:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 05:59:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:00:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:00:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:00:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:00:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:00:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:02:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:02:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:03:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:03:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:04:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:04:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:04:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 12:12:14 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 12:12:14 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 12:12:18 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 12:12:18 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 12:12:21 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 06:51:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:51:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:51:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:52:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:52:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:52:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:52:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:53:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 06:53:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 06:53:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:06:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:06:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:06:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:06:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 12:51:04 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 492
ERROR - 2020-08-12 12:51:04 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-08-12 12:51:04 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 493
ERROR - 2020-08-12 07:26:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:26:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:26:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 07:31:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 07:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:31:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:32:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:32:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 07:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 07:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 07:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 07:34:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:45:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:45:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:47:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:47:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:47:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:47:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:48:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:48:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:51:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:47 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:51:47 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:52:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:52:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:52:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:52:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 08:53:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:53:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 08:53:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 14:28:12 --> Severity: error --> Exception: syntax error, unexpected end of file /home/themes91/public_html/ci/e-academy/application/views/admin/student_manage.php 162
ERROR - 2020-08-12 09:01:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:01:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:01:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:01:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:02:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:02:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:04:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:04:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:05:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:07:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:07:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:23:17 --> 404 Page Not Found: Admin/index
ERROR - 2020-08-12 09:23:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:23:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:23:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:23:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:23:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:26:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:26:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:26:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:26:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:27:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:27:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:27:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:27:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:29:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:29:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:29:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:29:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:30:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:30:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:30:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:30:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:31:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:31:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:35:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:35:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:36:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:36:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:36:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:36:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:37:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:37:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:37:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:37:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:38:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:40:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:40:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:43:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:43:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:44:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:44:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:44:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:44:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:32 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:32 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:45:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:46:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:46:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:49:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:49:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:49:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:49:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:51:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:51:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:54:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:54:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:54:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:54:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:56:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:56:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:56:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:56:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:56:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:56:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:56:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:56:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:03 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:03 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 09:58:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:58:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:59:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 09:59:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:02:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:02:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:02:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:03:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:03:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:04:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:04:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:05:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:05:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:05:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:05:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:06:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:06:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:07:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:07:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:08:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:08:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:11:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:11:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:12:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:12:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:14:48 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:14:48 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:15:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:15:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:07 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:07 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:16:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:17:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:17:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:18:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:18:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:18:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:18:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:19:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:19:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:21:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:21:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:23:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:23:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:27:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:27:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:28:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:28:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:28:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:28:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:30:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:30:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:30:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:30:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:31:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:31:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:31:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:31:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:32:40 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:32:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:32:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:32:40 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:34:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:34:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 16:09:04 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 16:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 16:09:04 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-12 16:09:04 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-12 16:09:05 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-08-12 16:09:05 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-08-12 16:09:05 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 271
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 26
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 28
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 32
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:11:20 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:41:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:41:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:41:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:41:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 16:14:34 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:14:34 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:14:35 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 864
ERROR - 2020-08-12 10:44:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:44:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:44:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 16:14:46 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:14:46 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:14:47 --> Severity: Notice --> Undefined variable: dataarray /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 864
ERROR - 2020-08-12 16:15:22 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:15:22 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:15:48 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:15:48 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:15:49 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:15:49 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:15:51 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:15:51 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:15:57 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:15:57 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:16:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:16:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:16:04 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:16:04 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:16:05 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:16:05 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 16:16:05 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:16:05 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:46:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:46:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:46:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:47:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:47:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:47:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:47:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:48:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:48:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:48:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:49:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:49:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:49:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:49:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 16:19:59 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-08-12 16:19:59 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 73
ERROR - 2020-08-12 10:51:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:51:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:51:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:51:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:54:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:54:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:54:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:54:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:56:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:56:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 10:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 10:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 11:04:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-08-12 11:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 11:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 11:04:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-08-12 12:32:41 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 655
ERROR - 2020-08-12 18:37:08 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 18:37:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 117
ERROR - 2020-08-12 18:37:08 --> Severity: Notice --> Undefined variable: batches /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
ERROR - 2020-08-12 18:37:08 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 128
