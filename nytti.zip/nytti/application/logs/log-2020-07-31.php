<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-31 05:13:25 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:13:25 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:17:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:17:06 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:22:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:22:19 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:30:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:30:26 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:40:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:40:10 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:40:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:42:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:42:26 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:42:58 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:42:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:43:03 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:43:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:43:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:43:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:43:18 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 05:43:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:48:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:48:12 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:50:03 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:50:03 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:50:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:23:51 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 05:54:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:54:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:25:01 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 11:25:14 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-07-31 05:57:14 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:57:14 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:57:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:57:29 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 05:59:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 05:59:40 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 11:33:04 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 11:33:52 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 06:04:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:04:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:04:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 06:06:40 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:06:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:10:53 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:10:53 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:11:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 06:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:11:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:12:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:12:17 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:13:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:13:31 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:16:38 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:16:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:19:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:19:12 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:21:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:21:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 11:51:25 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 11:51:38 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 11:52:09 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 06:23:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:23:27 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 06:23:27 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:24:00 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:24:00 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 06:24:06 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:24:06 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:24:09 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 11:54:10 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 06:24:48 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:24:49 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 12:07:37 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/api/Home.php 20
ERROR - 2020-07-31 06:38:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-31 06:38:41 --> 404 Page Not Found: api/Welcome/update_app_used
ERROR - 2020-07-31 06:38:41 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-31 06:42:59 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT *
FROM exams  use index (id)
JOIN `mock_result` ON `mock_result`.`paper_id`=`exams`.`id`
WHERE `admin_id` = '1'
AND `mock_sheduled_date` <= '2020-07-31'
ORDER BY `exams`.`id` DESC
 LIMIT 1
ERROR - 2020-07-31 06:45:14 --> Severity: Notice --> Undefined variable: exam_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 30
ERROR - 2020-07-31 06:46:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:46:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 06:46:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 11:09:29 --> Unable to load the requested class: Admincommon
ERROR - 2020-07-31 16:47:26 --> Severity: Notice --> Undefined index: total_student /home/themes91/public_html/ci/e-academy/application/views/admin/dashboard.php 14
ERROR - 2020-07-31 11:19:56 --> Severity: Notice --> Undefined variable: total_student /home/themes91/public_html/ci/e-academy/application/libraries/Admincommon.php 17
ERROR - 2020-07-31 11:20:44 --> Severity: Notice --> Undefined property: Admincommon::$db_model /home/themes91/public_html/ci/e-academy/application/libraries/Admincommon.php 10
ERROR - 2020-07-31 11:20:44 --> Severity: error --> Exception: Call to a member function countAll() on null /home/themes91/public_html/ci/e-academy/application/libraries/Admincommon.php 10
ERROR - 2020-07-31 11:20:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-07-31 11:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 11:33:14 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 11:33:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 11:38:42 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 618
ERROR - 2020-07-31 11:38:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 618
ERROR - 2020-07-31 11:43:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-31 11:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 11:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-31 11:43:40 --> 404 Page Not Found: Admin/result_test
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: limit /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 520
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 575
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 591
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:00 --> Severity: Notice --> Undefined variable: post /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 599
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 575
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 591
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: type /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 556
ERROR - 2020-07-31 11:44:36 --> Severity: Notice --> Undefined variable: post /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 599
ERROR - 2020-07-31 11:45:27 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 575
ERROR - 2020-07-31 11:45:27 --> Severity: Notice --> Undefined variable: count /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 591
ERROR - 2020-07-31 11:45:27 --> Severity: Notice --> Undefined variable: post /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 599
ERROR - 2020-07-31 11:47:03 --> Severity: Notice --> Undefined variable: post /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 600
ERROR - 2020-07-31 11:48:05 --> Severity: Notice --> Undefined variable: post /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 600
ERROR - 2020-07-31 11:57:08 --> Severity: error --> Exception: syntax error, unexpected '$table_name' (T_VARIABLE) /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 486
ERROR - 2020-07-31 12:01:29 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 504
ERROR - 2020-07-31 12:02:59 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 504
ERROR - 2020-07-31 12:04:58 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 504
ERROR - 2020-07-31 12:09:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `mock_result`.`admin_id` = '1'
AND `mock_result`.`paper_id` = '29'
ORDER B' at line 4 - Invalid query: SELECT `mock_result`.*, `students`.`name`, `students`.`image`, `students`.`enrollment_id`
FROM mock_result use index (id)
JOIN `students` ON `students`.`id` = .`student_id`
WHERE `mock_result`.`admin_id` = '1'
AND `mock_result`.`paper_id` = '29'
ORDER BY .`id` DESC
ERROR - 2020-07-31 12:10:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `mock_result`.`admin_id` = '1'
AND `mock_result`.`paper_id` = '29'
ORDER B' at line 4 - Invalid query: SELECT `mock_result`.*, `students`.`name`, `students`.`image`, `students`.`enrollment_id`
FROM mock_result use index (id)
JOIN `students` ON `students`.`id` = .`student_id`
WHERE `mock_result`.`admin_id` = '1'
AND `mock_result`.`paper_id` = '29'
ORDER BY .`id` DESC
ERROR - 2020-07-31 12:51:48 --> Severity: Warning --> usort() expects parameter 2 to be a valid callback, function 'date_compare' not found or invalid function name /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 533
ERROR - 2020-07-31 12:52:22 --> Severity: Warning --> usort() expects parameter 2 to be a valid callback, function 'date_compare' not found or invalid function name /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 533
ERROR - 2020-07-31 12:52:51 --> Severity: error --> Exception: Too few arguments to function Admin_profile::date_compare(), 0 passed in /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php on line 533 and exactly 2 expected /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 538
ERROR - 2020-07-31 12:53:25 --> Severity: Notice --> Undefined property: Admin_profile::$date_compare /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 533
ERROR - 2020-07-31 12:53:25 --> Severity: Warning --> usort() expects parameter 2 to be a valid callback, no array or string given /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 533
ERROR - 2020-07-31 13:06:16 --> 404 Page Not Found: Admin_profile/result_test
