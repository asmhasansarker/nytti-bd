<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-30 04:57:01 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 04:57:01 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 05:00:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 05:00:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 05:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 05:49:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 05:49:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:06:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:06:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:06:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:06:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:06:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:07:57 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:07:57 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:40:02 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3708
ERROR - 2020-07-30 06:15:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:15:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:15:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:16:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:16:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:16:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:17:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:17:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:19:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:19:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:24:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:27:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:27:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:32:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:32:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:32:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:33:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:33:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:33:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:34:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:34:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:34:13 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:35:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 06:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:35:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:35:42 --> 404 Page Not Found: Ajaxcall/edit_live_class_setting
ERROR - 2020-07-30 06:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:35:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 06:35:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 14:38:09 --> Severity: Notice --> Undefined variable: id /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3758
ERROR - 2020-07-30 09:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:08:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:08:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:08:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:15:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:15:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:15:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:16:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:16:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 14:48:46 --> Query error: Unknown column 'live_class_id' in 'field list' - Invalid query: INSERT INTO `live_class_setting` (`batch`, `zoom_api_key`, `zoom_api_secret`, `meeting_number`, `password`, `live_class_id`, `status`, `added_at`, `admin_id`) VALUES ('20', 'VP4aNkDwQsGmMbqpQm0RuA', 'WtWcQVQXA3PXflkn0BBxp1gaU3kwS5voiAUK', '8818570544', '8gDwa7', '', '1', '2020-07-30 14:48:46', '1')
ERROR - 2020-07-30 09:18:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:18:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:18:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 14:49:07 --> Query error: Unknown column 'live_class_id' in 'field list' - Invalid query: INSERT INTO `live_class_setting` (`batch`, `zoom_api_key`, `zoom_api_secret`, `meeting_number`, `password`, `live_class_id`, `status`, `added_at`, `admin_id`) VALUES ('20', 'VP4aNkDwQsGmMbqpQm0RuA', 'WtWcQVQXA3PXflkn0BBxp1gaU3kwS5voiAUK', '8818570544', '8gDwa7', '', '1', '2020-07-30 14:49:07', '1')
ERROR - 2020-07-30 09:20:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:20:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:20:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:39:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:39:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:39:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:46:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 09:46:04 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 09:47:55 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 09:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:47:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 09:49:08 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 09:49:08 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 09:53:23 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 09:53:23 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 09:59:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 09:59:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:04:29 --> 404 Page Not Found: Admin/start-class
ERROR - 2020-07-30 10:05:21 --> Severity: error --> Exception: Call to undefined method Admin_profile::manage_session() /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 441
ERROR - 2020-07-30 10:05:43 --> Severity: Notice --> Undefined index: batch_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 445
ERROR - 2020-07-30 10:05:43 --> Severity: Notice --> Undefined property: Admin_profile::$Homemodel /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 449
ERROR - 2020-07-30 10:05:43 --> Severity: error --> Exception: Call to a member function librarydata() on null /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 449
ERROR - 2020-07-30 10:05:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-07-30 10:10:36 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 451
ERROR - 2020-07-30 10:10:36 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 454
ERROR - 2020-07-30 10:10:36 --> Severity: Notice --> Undefined index: meeting_password /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 455
ERROR - 2020-07-30 10:11:04 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 451
ERROR - 2020-07-30 10:11:04 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 454
ERROR - 2020-07-30 10:11:04 --> Severity: Notice --> Undefined index: meeting_password /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 455
ERROR - 2020-07-30 10:11:09 --> 404 Page Not Found: Admin/end_metting
ERROR - 2020-07-30 10:12:30 --> 404 Page Not Found: Admin/end_metting
ERROR - 2020-07-30 10:12:44 --> 404 Page Not Found: Admin/end_metting
ERROR - 2020-07-30 10:13:30 --> Severity: Notice --> Undefined property: Admin_profile::$Homemodel /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 472
ERROR - 2020-07-30 10:13:30 --> Severity: error --> Exception: Call to a member function update_data() on null /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 472
ERROR - 2020-07-30 10:13:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-07-30 10:14:17 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 451
ERROR - 2020-07-30 10:14:17 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 454
ERROR - 2020-07-30 10:14:17 --> Severity: Notice --> Undefined index: meeting_password /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 455
ERROR - 2020-07-30 10:14:46 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 451
ERROR - 2020-07-30 10:14:46 --> Severity: Notice --> Undefined index: meeting_id /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 454
ERROR - 2020-07-30 10:14:46 --> Severity: Notice --> Undefined index: meeting_password /home/themes91/public_html/ci/e-academy/application/controllers/Admin_profile.php 455
ERROR - 2020-07-30 10:16:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:16:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:16:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:19:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:19:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:23:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:23:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 16:01:52 --> Severity: Notice --> Undefined variable: data /home/themes91/public_html/ci/e-academy/application/controllers/Teacher_profile.php 228
ERROR - 2020-07-30 10:31:52 --> 404 Page Not Found: Ajaxcall/live_class_list_teacher
ERROR - 2020-07-30 10:33:11 --> 404 Page Not Found: Ajaxcall/live_class_list_teacher
ERROR - 2020-07-30 10:33:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:33:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:33:29 --> 404 Page Not Found: Ajaxcall/live_class_list_teacher
ERROR - 2020-07-30 10:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:33:30 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:33:30 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:34:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:34:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:37:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:37:37 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:38:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:39:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:39:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:39:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:41:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:41:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:43:07 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:43:07 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 16:13:12 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `admin_id` = `1,19` AND `batches`.`id` in (1,19)
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 10:43:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:43:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:43:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:43:21 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:43:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 16:13:22 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `admin_id` = `1,19` AND `batches`.`id` in (1,19)
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 10:43:30 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 16:13:34 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 16:13:34 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 16:13:37 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `admin_id` = `1,19` AND `batches`.`id` in (1,19)
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 10:43:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:43:41 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:44:29 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:44:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:44:29 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 16:14:29 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT `live_class_setting`.*, `batches`.`batch_name`
FROM `live_class_setting`
JOIN `batches` ON `batches`.`id`=`live_class_setting`.`batch`
WHERE `admin_id` = 1 AND `batches`.`id` in (1,19)
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 10:45:16 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 10:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:45:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 10:48:18 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:48:18 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:48:58 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:48:58 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:50:38 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:50:38 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 10:51:07 --> 404 Page Not Found: Teacher/start-class
ERROR - 2020-07-30 10:57:21 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 10:57:21 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 16:30:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-07-30 16:30:02 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 70
ERROR - 2020-07-30 11:01:00 --> 404 Page Not Found: Teacher/end_metting
ERROR - 2020-07-30 11:01:10 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 11:01:10 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 16:31:45 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-07-30 16:31:45 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 70
ERROR - 2020-07-30 11:02:26 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 11:02:26 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 11:03:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:03:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:03:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:03:52 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 11:03:52 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 11:06:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:06:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:08:31 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 11:08:31 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 11:12:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 11:12:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 11:21:54 --> 404 Page Not Found: Student/start-class
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined variable: ins /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 70
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 72
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 74
ERROR - 2020-07-30 11:22:42 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 75
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 71
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 72
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 74
ERROR - 2020-07-30 11:24:14 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/controllers/Student_profile.php 75
ERROR - 2020-07-30 11:47:27 --> 404 Page Not Found: Admin/live-class-history
ERROR - 2020-07-30 11:52:05 --> 404 Page Not Found: Ajaxcall/live_class_history_table
ERROR - 2020-07-30 17:25:42 --> Query error: Unknown column 'live_class_setting.admin_id' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
WHERE `live_class_setting`.`admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 17:27:23 --> Query error: Unknown column 'live_class_setting.admin_id' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
WHERE `live_class_setting`.`admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 11:57:26 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:57:26 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:57:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:27:33 --> Query error: Unknown column 'live_class_setting.admin_id' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
WHERE `live_class_setting`.`admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 11:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:57:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:57:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:58:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:58:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:09 --> Severity: Notice --> Undefined index: batch_name /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 11:58:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:58:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 17:28:52 --> Severity: Notice --> Undefined index: batch /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3878
ERROR - 2020-07-30 11:58:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:59:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 11:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 11:59:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:31:48 --> Query error: Unknown column 'users.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM batches use index (id)
WHERE `admin_id` = '1'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
AND  `users`.`name` LIKE '%m%' ESCAPE '!'
ERROR - 2020-07-30 12:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:01:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 17:31:58 --> Query error: Unknown column 'users.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM batches use index (id)
WHERE `admin_id` = '1'
AND  `users`.`name` LIKE '%mo%' ESCAPE '!'
AND  `users`.`name` LIKE '%mo%' ESCAPE '!'
ERROR - 2020-07-30 12:06:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:06:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:06:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:12:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:12:51 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 17:42:55 --> Query error: Unknown column 'users.name,batches.batch_name' in 'group statement' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
GROUP BY `users`.`name,batches`.`batch_name`, `$post["search"]["value"],$post["search"]["value"]`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 12:13:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:13:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:13:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:13:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:13:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:43:13 --> Query error: Unknown column 'users.name,batches.batch_name' in 'group statement' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
GROUP BY `users`.`name,batches`.`batch_name`, `$post["search"]["value"],$post["search"]["value"]`
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 12:14:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:14:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:44:05 --> Query error: Unknown column 'u' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
WHERE `u` LIKE '%s%' ESCAPE '!'
OR  `$` LIKE '%p%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 12:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:14:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:14:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 17:44:13 --> Query error: Unknown column 'u' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
WHERE `u` LIKE '%s%' ESCAPE '!'
OR  `$` LIKE '%p%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 12:15:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:45:42 --> Query error: Unknown column 'u' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
WHERE `u` LIKE '%s%' ESCAPE '!'
OR  `a` LIKE '%,%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 12:18:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:18:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:18:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 17:48:38 --> Severity: Notice --> Uninitialized string offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 59
ERROR - 2020-07-30 17:48:38 --> Query error: Unknown column 'u' in 'where clause' - Invalid query: SELECT `live_class_history`.*, `users`.`name`, `batches`.`batch_name`
FROM `live_class_history`
JOIN `users` ON `users`.`id`=`live_class_history`.`uid`
JOIN `batches` ON `batches`.`id`=`live_class_history`.`batch_id`
WHERE `u` LIKE '%s%' ESCAPE '!'
OR  `a` LIKE '%%' ESCAPE '!'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-07-30 17:48:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-07-30 12:19:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 12:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:19:23 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:20:43 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:20:43 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:24:35 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:24:35 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:26:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:26:04 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:26:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:26:05 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:28:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:28:51 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 18:01:16 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 18:01:16 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 18:01:44 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 18:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 18:01:45 --> Severity: Notice --> Undefined variable: teacher /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 18:01:45 --> Severity: Warning --> Invalid argument supplied for foreach() /home/themes91/public_html/ci/e-academy/application/views/admin/extra_classes.php 93
ERROR - 2020-07-30 12:32:54 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:35:45 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:35:45 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:37:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:37:55 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:38:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:38:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:40:05 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:40:05 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:41:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:41:52 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:42:12 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:42:27 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:42:28 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:42:51 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:43:04 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:43:05 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:45:11 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:45:11 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 18:18:42 --> Severity: 4096 --> Object of class DateTime could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 54
ERROR - 2020-07-30 18:18:42 --> Severity: 4096 --> Object of class DateTime could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/api/Exam.php 54
ERROR - 2020-07-30 12:48:55 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:48:55 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:51:56 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:51:56 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 12:52:17 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:53:13 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 12:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:57:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 12:57:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 13:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 13:11:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-07-30 13:11:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-07-30 13:12:22 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 13:12:23 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 13:12:24 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 13:12:25 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 13:14:19 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 13:14:19 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 13:15:36 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 13:15:36 --> 404 Page Not Found: api/Welcome/show_survey
ERROR - 2020-07-30 13:15:49 --> 404 Page Not Found: api/Notice/show_ads
ERROR - 2020-07-30 13:15:49 --> 404 Page Not Found: api/Welcome/show_survey
