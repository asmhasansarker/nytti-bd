<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-14 05:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:33:17 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:33:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-14 05:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-14 05:54:53 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-14 05:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-14 05:54:54 --> 404 Page Not Found: Assets/js
