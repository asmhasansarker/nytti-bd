<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-09-12 11:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-12 11:05:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-12 11:05:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-09-12 11:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-12 11:15:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-09-12 11:15:37 --> 404 Page Not Found: Assets/css
