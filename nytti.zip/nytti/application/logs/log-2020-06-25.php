<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3366
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3368
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3369
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: added_by /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3371
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3366
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3368
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3369
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: added_by /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3371
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3366
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3368
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: vid /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3369
ERROR - 2020-06-25 16:17:44 --> Severity: Notice --> Undefined variable: added_by /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3371
ERROR - 2020-06-25 16:21:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:21:01 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:21:01 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:28:54 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:28:54 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:28:55 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:30:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:30:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:30:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:30:37 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:32:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:32:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:32:53 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:33:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:33:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:33:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:35:43 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 16:35:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:35:43 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 16:43:10 --> 404 Page Not Found: Ajaxcall/manage_leaves
ERROR - 2020-06-25 17:11:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:11:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:12:05 --> Severity: error --> Exception: Too few arguments to function Ajaxcall::manage_leaves(), 0 passed in /home/themes91/public_html/ci/e-academy/system/core/CodeIgniter.php on line 532 and exactly 1 expected /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3450
ERROR - 2020-06-25 17:12:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:12:17 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:12:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:12:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:12:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:24:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:24:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:24:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:24:34 --> Query error: Unknown column 'leave_management.added_date' in 'field list' - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_date`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id`
WHERE `student_id` != '0'
AND `admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-25 17:26:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:26:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:26:15 --> Query error: Column 'admin_id' in where clause is ambiguous - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id`
WHERE `student_id` != '0'
AND `admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-25 17:27:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:27:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:27:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:27:35 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id`
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `id` DESC
 LIMIT 10
ERROR - 2020-06-25 17:29:23 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:29:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:29:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:33:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:33:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:33:27 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 30
ERROR - 2020-06-25 17:33:27 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 30
ERROR - 2020-06-25 17:33:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'as leave_id
AND  10 LIKE '%0%' ESCAPE '!'
OR  `s` LIKE '%t%' ESCAPE '!'
OR  `l` ' at line 4 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`
FROM `leave_management`.`status`
JOIN `leave_management`.`id` USING (`desc`)
WHERE leave_management.id as leave_id
AND  10 LIKE '%0%' ESCAPE '!'
OR  `s` LIKE '%t%' ESCAPE '!'
OR  `l` LIKE '%e%' ESCAPE '!'
 LIMIT 0
ERROR - 2020-06-25 17:33:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-25 17:36:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:36:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:36:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:36:15 --> Severity: Notice --> Undefined offset: 0 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 30
ERROR - 2020-06-25 17:36:15 --> Severity: Notice --> Undefined offset: 1 /home/themes91/public_html/ci/e-academy/application/models/Db_model.php 30
ERROR - 2020-06-25 17:36:15 --> Query error: SELECT command denied to user 'themes91_eacademy'@'localhost' for table 'status' - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`
FROM `leave_management`.`status`
JOIN `leave_management`.`id` USING (`desc`)
WHERE `leave_management`.`id` IS NULL
AND  10 LIKE '%0%' ESCAPE '!'
OR  `s` LIKE '%t%' ESCAPE '!'
OR  `l` LIKE '%e%' ESCAPE '!'
 LIMIT 0
ERROR - 2020-06-25 17:36:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-25 17:50:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:50:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:50:16 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:50:17 --> Severity: Notice --> Undefined variable: leave /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3496
ERROR - 2020-06-25 17:50:17 --> Severity: Notice --> Undefined variable: course /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3499
ERROR - 2020-06-25 17:50:17 --> Severity: Notice --> Undefined variable: leave /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3496
ERROR - 2020-06-25 17:50:17 --> Severity: Notice --> Undefined variable: course /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3499
ERROR - 2020-06-25 17:54:13 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 17:54:14 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 17:54:20 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 18:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 18:07:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 18:07:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 18:08:25 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-25 18:08:25 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-25 18:08:25 --> 404 Page Not Found: Assets/js
