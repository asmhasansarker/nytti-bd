<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 01:30:32 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3562
ERROR - 2020-06-28 01:30:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name')%'' at line 3 - Invalid query: SELECT `name`
FROM `students`
WHERE `name` LIKE '%->post('name')%'
ERROR - 2020-06-28 01:30:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-28 01:38:13 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3562
ERROR - 2020-06-28 01:38:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name')%'' at line 3 - Invalid query: SELECT `name`
FROM `students`
WHERE `name` LIKE '%->post('name')%'
ERROR - 2020-06-28 01:38:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-28 01:42:24 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3562
ERROR - 2020-06-28 01:42:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name')%'' at line 1 - Invalid query: Select name from students where name LIKE '%->post('name')%'
ERROR - 2020-06-28 01:42:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-28 01:42:53 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3562
ERROR - 2020-06-28 01:42:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'name')%'' at line 1 - Invalid query: Select name from students where name LIKE '%->post('name')%'
ERROR - 2020-06-28 01:42:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-28 01:43:55 --> Severity: 4096 --> Object of class CI_Input could not be converted to string /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3562
ERROR - 2020-06-28 01:43:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.->post('name').'%'' at line 3 - Invalid query: SELECT `name`
FROM `students`
WHERE `name` LIKE '%'.->post('name').'%'
ERROR - 2020-06-28 01:43:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/themes91/public_html/ci/e-academy/system/core/Exceptions.php:271) /home/themes91/public_html/ci/e-academy/system/core/Common.php 570
ERROR - 2020-06-28 01:48:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's'%'' at line 3 - Invalid query: SELECT `name`
FROM `students`
WHERE `name` LIKE '%'s'%'
ERROR - 2020-06-28 14:00:31 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:00:31 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:00:31 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 14:00:31 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 08:30:35 --> 404 Page Not Found: Teacher/create-exam
ERROR - 2020-06-28 14:04:19 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:04:19 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:04:19 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 14:04:19 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 08:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:37:50 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:37:50 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 14:09:09 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-28 14:09:09 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-28 08:39:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:39:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:39:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:12:03 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 62
ERROR - 2020-06-28 14:12:03 --> Severity: Notice --> Undefined variable: profile /home/themes91/public_html/ci/e-academy/application/views/common/admin_header.php 67
ERROR - 2020-06-28 08:42:04 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:42:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:42:04 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:42:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:42:09 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:42:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:44:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:44:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:44:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:47:19 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:47:19 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:27:41 --> Query error: Unknown column 'batch_id' in 'where clause' - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `batch_id` in (1,19)
ERROR - 2020-06-28 08:57:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:57:44 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:57:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:57:46 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:57:46 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:27:46 --> Query error: Unknown column 'batch_id' in 'where clause' - Invalid query: SELECT `id`, `batch_name`
FROM batches use index (id)
WHERE `admin_id` = 1 AND `batch_id` in (1,19)
ERROR - 2020-06-28 08:58:18 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 08:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 08:58:18 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:10:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:10:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:13:20 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:13:21 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:19:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:19:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:23:00 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:23:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:23:00 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:54:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:54:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 20
ERROR - 2020-06-28 14:54:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 14:54:28 --> Severity: Notice --> Undefined index: no_of_questions /home/themes91/public_html/ci/e-academy/application/views/admin/question_manage.php 95
ERROR - 2020-06-28 09:24:36 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:24:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:24:36 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:24:49 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:24:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:24:49 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:57:38 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 14:57:38 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 14:57:38 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 09:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:27:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:27:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:27:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 14:57:51 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 14:57:51 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 14:57:51 --> Severity: Notice --> Undefined index: total_days /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3579
ERROR - 2020-06-28 09:28:24 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:28:24 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:32:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:32:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:34:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:34:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:34:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:34:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:34:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:36:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:36:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:36:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:06:15 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `name` LIKE '%s%' ESCAPE '!'
AND  `name` LIKE '%s%' ESCAPE '!'
ERROR - 2020-06-28 09:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:36:41 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:36:41 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 15:06:42 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `name` LIKE '%s%' ESCAPE '!'
AND  `name` LIKE '%s%' ESCAPE '!'
ERROR - 2020-06-28 15:06:42 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `name` LIKE '%s%' ESCAPE '!'
AND  `name` LIKE '%s%' ESCAPE '!'
ERROR - 2020-06-28 09:42:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:42:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:44:08 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:44:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:44:08 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:44:56 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:44:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:44:56 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:46:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:46:59 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:46:59 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 15:17:02 --> Query error: Unknown column 'name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `name` LIKE '%h%' ESCAPE '!'
AND  `name` LIKE '%h%' ESCAPE '!'
ERROR - 2020-06-28 09:48:27 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:48:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:48:27 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:18:30 --> Query error: Unknown column 'studentsname' in 'where clause' - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id`
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `studentsname` LIKE '%n%' ESCAPE '!'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 15:19:25 --> Query error: Unknown column 'students.name' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM leave_management use index (user_id)
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
AND  `students`.`name` LIKE '%n%' ESCAPE '!'
AND  `students`.`name` LIKE '%n%' ESCAPE '!'
ERROR - 2020-06-28 09:53:35 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:53:35 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:23:35 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3565
ERROR - 2020-06-28 15:23:35 --> Severity: Notice --> Undefined variable: or_like /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3565
ERROR - 2020-06-28 15:23:35 --> Severity: Notice --> Undefined variable: like /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3591
ERROR - 2020-06-28 15:23:35 --> Severity: Notice --> Undefined variable: or_like /home/themes91/public_html/ci/e-academy/application/controllers/Ajaxcall.php 3591
ERROR - 2020-06-28 15:24:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `' at line 3 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id` AND `students`.`name` LIKE %n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 09:54:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:54:42 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:24:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `' at line 3 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id` AND `students`.`name` LIKE %n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 09:56:06 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:56:06 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:26:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `' at line 3 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id` AND `students`.`name` LIKE %n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 15:26:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%s%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `' at line 3 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id` AND `students`.`name` LIKE %s%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 09:58:22 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 09:58:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 09:58:22 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 15:28:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '%n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `' at line 3 - Invalid query: SELECT `leave_management`.`subject`, `leave_management`.`leave_msg`, `leave_management`.`total_days`, `leave_management`.`from_date`, `leave_management`.`to_date`, `leave_management`.`added_at`, `leave_management`.`status`, `leave_management`.`id` as `leave_id`, `students`.`name`
FROM `leave_management`
JOIN `students` ON `leave_management`.`student_id` = `students`.`id` AND `students`.`name` LIKE %n%
WHERE `student_id` != '0'
AND `leave_management`.`admin_id` = '1'
ORDER BY `leave_management`.`id` DESC
 LIMIT 10
ERROR - 2020-06-28 10:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:00:45 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:04:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:04:51 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:04:51 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:07:44 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:07:45 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:10:09 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:10:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:10:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:10:11 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:10:11 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:14:39 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:14:39 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:15:15 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:15:15 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:18:52 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:18:52 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:20:34 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:20:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:20:34 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:21:10 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:21:10 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:22:02 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:22:02 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:23:28 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:23:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:23:28 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:12 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:12 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:33 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:26:33 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:58 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:26:58 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:28:37 --> 404 Page Not Found: Assets/css
ERROR - 2020-06-28 10:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:28:38 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:29:31 --> 404 Page Not Found: Assets/js
ERROR - 2020-06-28 10:29:31 --> 404 Page Not Found: Assets/css
